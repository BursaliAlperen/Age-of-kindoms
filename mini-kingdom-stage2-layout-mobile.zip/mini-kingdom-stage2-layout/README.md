# Mini Kingdom - Stage 2: Kale v4, Sabit İnşa Bölgeleri, Arayüz

Bu paket üç işi kapsar: detaylı kale çizimi, oyun haritasının sabit bölge/slot verisi
(JSON) ve bu veriye bağlı inşa menüsü arayüzü. Hepsi tek bir kaynak dosyadan (`layout/kingdom_layout.json`)
beslenir; yeni bina veya bölge eklemek için kodu değil veriyi değiştirmek yeterli.

## Klasörler

| Yol | İçerik |
|---|---|
| `art/castle_v4_25d.png` | Yeni kale (220x149), 3x önizleme: `castle_v4_25d_3x.png` |
| `art/buildings/` | Haritada ve arayüzde kullanılan bina sprite'ları (`academy25.png` troops-academy paketinden) |
| `art/tiles/` | Harita zemini için çimen karoları |
| `layout/kingdom_layout.json` | **Ana veri dosyası**: harita boyutu, kurallar, bölge tipleri, bina kataloğu, bölgeler, slotlar |
| `layout/map_preview.png` | Bölgelerin ve slotların görsel haritası |
| `gui/build_menu.html` | İnşa menüsü arayüzü (tarayıcıda çift tıklayıp açılır) |
| `gui/build_menu.png` | Arayüzün ekran görüntüsü |
| `tools/validate_layout.py` | Bölge/slot doğrulayıcı (sadece Python 3) |
| `tools/render_map.py` | JSON'dan harita PNG'si üretir |
| `tools/build_gui.py` | JSON'dan `build_menu.html` üretir |
| `tools/build_castle_v4.py` + `tools/src/` | Kale çizim betiği (mevcut `core/build/build25/tiles` yardımcılarını kullanır) |

## Harita düzeni (40 x 30 tile, 1 tile = 32 px)

- **Kale Çekirdeği** (`z_keep`): merkezde. Kale (6x5) ve 2 okçu kulesi.
- **Askeri Bölge** (`z_military`): kuzey-batı. 3 kışla, 1 akademi, 1 silah deposu (demirhane), 2 talim alanı, 4 nöbet noktası.
- **Sivil Yerleşim** (`z_civil`): kuzey-doğu, askeriyeden boşlukla ayrılmış. 6 ev, 1 şifahane, 1 pazar, 1 hamam, 1 kilise/cami.
- **Maden** (`z_mine`): güney-batı, **2 ayrı dikdörtgen**. 3 taş ocağı.
- **Orman** (`z_forest`): güney-doğu, **2 ayrı dikdörtgen**. 3 oduncu, 1 depo.
- **Tarla** (`z_field`): güney-orta, **2 ayrı dikdörtgen**. 4 çiftlik.

Her bina, sadece izinli olduğu bölgede ve önceden tanımlı slotta yer alır. Slotlar sabittir; oyun
sırasında yeni yer açılmaz, sadece slot dolar/boşalır.

## Doğrulama kuralları

`python3 tools/validate_layout.py layout/kingdom_layout.json` şu kuralları kontrol eder:

1. Kimlikler benzersiz (bölge ve slot).
2. Bölge dikdörtgenleri geçerli ve harita içinde; kaynak bölgeleri en az 2 dikdörtgen.
3. Farklı bölgeler birbiriyle çakışmaz.
4. Askeri ve sivil bölgeler birbirine değmez (aralarında boşluk şart).
5. Her slot tanımlı bina olmalı ve boyutu katalogla birebir eşleşmeli.
6. Her slot, kendi bölgesinin tamamında kalmalı.
7. Bina, izinli olmadığı bölgeye konamaz (ör. kışla sivil bölgede).
8. Slotlar birbiriyle çakışmaz ve aralarında en az 1 tile boşluk bulunur.
9. Bina başına adet limiti aşılmaz.
10. Tam olarak 1 kale bulunur.

Doğrulayıcı, bozulmuş düzenlerle test edildi (çakışma, bölge dışı slot, yanlış bölge, tek dikdörtgenli
maden, harita dışı, slot boşluğu, iki kale); her biri hata olarak yakalandı.

## Veri dosyası nasıl genişletilir

- Yeni bina: `buildings` altına ekle (`footprint`, `max_count`, `allowed_zones`, `sprite`, `unlock`).
- Yeni slot: `slots` listesine ekle (`building`, `zone`, `x`, `y`, `w`, `h`). Boyut katalogla aynı olmalı.
- Yeni bölge parçası: ilgili bölgenin `rects` listesine dikdörtgen ekle. Kaynak bölgeleri için en az 2 dikdörtgen gerekir.
- Kural değiştirme: `rules` bölümündeki anahtarları aç/kapat veya `forbid_zone_touch` listesini düzenle.

Ardından `validate_layout.py`, `render_map.py` ve `build_gui.py` çalıştırılır.

## Komutlar (paket kökünden)

```
python3 tools/validate_layout.py layout/kingdom_layout.json
python3 tools/render_map.py layout/kingdom_layout.json art layout/map_preview.png
python3 tools/build_gui.py
python3 -I tools/build_castle_v4.py tools/src art
```

`render_map.py` DejaVu yazı tipini kullanır (`/usr/share/fonts/truetype/dejavu/`); yoksa varsayılan yazı tipine düşer.

## Bilinen sınırlar ve açık işler

- **Kale**: yeni çizim prosedürel olarak üretildi (2.5D, mevcut palet ve projeksiyonla). El çizimi
  bir sanatçının detayına henüz ulaşmadı; oran ve detay ayarı gerekebilir.
- **Sprite'ı olmayan binalar**: Talim Alanı, Hamam, Kilise/Cami. Haritada geçici etiketle gösteriliyor, sprite gerekiyor.
- **Nöbet noktası**: şimdilik okçu kulesi sprite'ının küçültülmüş hali kullanılıyor; ayrı sprite gerekiyor.
- **Arayüz durumu**: "Kurulu" işaretleri ve kale seviyesi kilitleri bir demo. Gerçek durum bağlandığında
  `BUILT` kümesi ve kilit mantığı oyun verisinden gelmeli.
- **Akademi ve asker tier'ları**: troops-academy paketindeki `soldiers_v3.py` ve `academy_v1.py` bu pakete
  dahil edilmedi; sadece akademi sprite'ı kullanıldı. Araştırma ağacı (JSON) bir sonraki adım.
- Slot yerleşimi oyuncu kamerasına ve kaydırmaya göre gözden geçirilmeli; mevcut düzen ilk taslak.

## Mobil arayüz (9:16) - sürüm 2

`gui/build_menu.html` artık 9:16 telefon ekranı için tasarlandı (önizleme 360x640 CSS px, 2x ekran yoğunluğu).

**Tasarım ilkeleri (Rise of Kingdoms tarzı, sadeleştirilmiş)**
- Üst çubukta sadece 4 kaynak ve kale seviyesi; metin yok, ikon + sayı.
- Harita tam ekran; kale merkezde açılır, sürükleyerek gezilir.
- Alt menüde 4 sekme (İnşa, Asker, Akademi, Harita); aktif sekme altın renkli.
- Bina seçimi alttan açılan panelle (bottom sheet), tek ana buton: "İnşa et".
- İnşa akışı: İnşa → bina seç → haritada yanıp sönen boş yerler → yeri seç → onayla.
  Yetersiz kaynakta buton kapanır, eksik kalem kırmızı görünür.
- Boş yerler küçük altın "+" işaretleri, kilitli binalar gri kilit ile gösterilir (kilit yalnız metin olarak açıklanır).
- Dokunma hedefleri en az ~34 px; tüm metinler 10-14 px aralığında.

**Not:** Rise of Kingdoms arayüzü hakkında web kaynakları ayrıntılı bir HUD tarifi vermedi; tasarım
genel olarak bilinen RoK düzenine (üst kaynak çubuğu, alt sekme menüsü, alttan panel) ve mobil strateji
oyunlarındaki yaygın kurallara dayanır. Gerçek oyun ekranıyla karşılaştırıp ayar yapılmalı.

**Dosyalar**
- `gui/build_menu.html`: mobil arayüz (veri gömülü, çift tıkla açılır)
- `gui/mobil_1_ana.png` … `gui/mobil_5_askeri_bolge.png`: ekran görüntüleri
- `layout/preview_state.json`: demo oyuncu durumu (kale seviyesi, kurulu binalar, maliyetler, kaynaklar).
  Oyun kodu bağlanınca bu dosyanın yerine gerçek kayıt gelir.
- `art/map_clean.png`: oyun içi temiz harita (`python3 tools/render_map.py --clean` ile üretilir).

**Komutlar (paket kökünden)**
```
python3 tools/render_map.py --clean
python3 tools/build_gui.py
```

**Sınırlar:** Demo durumda "Yükselt", "Asker", "Akademi" sekmeleri henüz bağlı değil; inşaat zamanlayıcısı
sadece gösterim (1.8 sn). Harita tek bir 1000 px genişlikte görsel; daha yüksek çözünürlük için sprite
ölçeği ve harita boyutu birlikte ayarlanmalı.
