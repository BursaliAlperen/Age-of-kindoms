"""Kale v4 - 2.5D detayli kale: merkez kule, 4 kose kulesi, demir parmakli kapi kulesi,
meşaleler, asma pankartlar, oklu ve gotik pencereler.
Kullanim: python3 -I build_castle_v4.py <src_dir> <out_dir>
"""
import sys, os
SRC, OUT = sys.argv[1], sys.argv[2]
sys.path.insert(0, SRC)
from core import *
from build import RED, BLUE, THA, SLT, STN, WD, PLS, FND, GRN, YEL, FIRE, IRN, GLS, CLY, flag
from build25 import P25, sh_stone, flat, hip_pyramid
from PIL import Image

W_, H_ = 260, 230
BX, BY = 118, 205
c = Cv(W_, H_)
p = P25(c, BX, BY)
DARK = (22, 14, 34)
glows = []

def fr(u0, u1, z0, z1, v, fn):
    """On-plane (v fixed) pixel fill: 1 unit = 1 px on front faces."""
    if not callable(fn): fn = solid(fn)
    for uu in range(u0, u1):
        for zz in range(z0, z1):
            col = fn(uu, zz)
            if col is None: continue
            x, y = p.pt(uu + .5, v, zz + .5)
            c.put(x, y, col)

def solid(col): return lambda u, z: col

def slit(u, v, z, h=9):
    def fn(uu, zz):
        if uu == u and zz >= z + h - 5: return YEL[4]
        if uu == u and zz >= z + h - 6: return YEL[2]
        return DARK
    fr(u, u + 2, z, z + h, v, fn)
    fr(u - 1, u + 3, z - 1, z, v, STN[5])

def gwin(u, v, z, w=5, h=11):
    def fn(uu, zz):
        top = (zz >= z + h - 2) and abs(uu + .5 - (u + w / 2)) > (h - zz + z) * .5 - 0.5
        if top: return None
        if uu in (u, u + w - 1): return STN[5]
        if zz >= z + h - 3 or uu == u + w // 2: return YEL[3] if zz < z + h - 1 else STN[5]
        return YEL[4]
    fr(u, u + w, z, z + h, v, fn)
    fr(u - 1, u + w + 1, z - 1, z, v, STN[5])
    fr(u + w // 2, u + w // 2 + 1, z, z + h - 3, v, solid(STN[2]))

def banner(u0, u1, v, zt, h, R):
    cx = (u0 + u1) / 2
    def fn(uu, zz):
        bottom = zt - h
        if abs(uu + .5 - cx) < 1.5 and zz < bottom + 4: return None        # ucu centik (swallowtail)
        if abs(uu + .5 - cx) + abs(zz + .5 - (zt - h / 2)) <= 3.2: return YEL[4]   # amblem (elmas)
        if uu in (u0, u1 - 1): return R[1]
        if uu < cx - 1: return R[4]
        return R[3] if (uu % 3) else R[2]
    fr(u0, u1, zt - h, zt, v, fn)
    fr(u0 - 1, u1 + 1, zt, zt + 1, v, WD[3])           # asma çubuğu
    fr(u0 - 2, u0 - 1, zt, zt + 2, v, IRN[4]); fr(u1 + 1, u1 + 2, zt, zt + 2, v, IRN[4])

def torch(u, z, v):
    x, y = p.pt(u + .5, v, z + .5)
    x, y = int(x), int(y)
    c.rect(x - 2, y, x + 3, y + 1, IRN[3])          # aplik kolu
    c.rect(x - 2, y - 2, x + 3, y, IRN[4])          # kase
    c.rect(x - 2, y - 2, x + 3, y - 1, IRN[5])
    c.rect(x - 1, y - 5, x + 2, y - 2, FIRE[4])     # alev
    c.rect(x, y - 8, x + 1, y - 5, FIRE[5])
    c.put(x, y - 9, (255, 250, 200))
    glows.append((x, y - 5))

# ---------- 1) arka kuleler ----------
for (u, v, R, seed) in ((-10, 24, BLUE, 201), (66, 24, RED, 211)):
    box_s = sh_stone(STN, seed, 6, 3); box_t = sh_stone(STN, seed + 1, 6, 3, -1.2)
    p.box(u, v, 0, 18, 18, 60, sh_stone(STN, seed + 2), sh_stone(STN, seed + 3, 9, 5, -1.2), flat(STN, 4))
    p.box(u - 1, v - 1, 60, 20, 20, 3, sh_stone(STN, seed + 4, 6, 3), sh_stone(STN, seed + 5, 6, 3, -1.2), flat(STN, 5))
    hip_pyramid(p, u, v, 63, 18, 18, 26, R, seed)
    slit(u + 7, v, 28, 9)
    x, y = p.pt(u + 9, v + 9, 89); flag(c, int(x), int(y) - 2, 20, R)

# ---------- 2) ana kule (keep) ----------
p.box(24, 14, 0, 26, 18, 70, sh_stone(STN, 101), sh_stone(STN, 102, 9, 5, -1.2), flat(STN, 4))
p.box(23, 13, 70, 28, 20, 3, sh_stone(STN, 103, 6, 3), sh_stone(STN, 104, 6, 3, -1.2), flat(STN, 5))
hip_pyramid(p, 24, 14, 73, 26, 18, 30, SLT, 7)
x, y = p.pt(37, 23, 103); flag(c, int(x), int(y) - 2, 24, YEL)
gwin(28, 14, 42, 5, 11)
gwin(45, 14, 42, 5, 11)
gwin(36, 14, 20, 4, 8)
banner(33, 41, 14, 60, 20, RED)

# ---------- 3) kale surları (ön duvar) ----------
p.box(0, 0, 0, 76, 34, 34, sh_stone(STN, 91, 9, 5, -1.3), sh_stone(STN, 92, 9, 5, -1.2), sh_stone(STN, 95, 9, 5, .2))
for uu in range(0, 76, 7):
    p.box(uu, 0, 34, 4, 3, 5, sh_stone(STN, 93, 6, 3), sh_stone(STN, 94, 6, 3, -1.2), flat(STN, 5))
for uu in (12, 20, 56, 64):
    slit(uu, 0, 16, 9)
# duvar dekor şeridi
fr(0, 76, 26, 28, 0, lambda u, z: STN[5] if (u % 9) else STN[4])

# ---------- 4) ön kuleler ----------
for (u, v, R, seed) in ((-10, -8, RED, 301), (66, -8, BLUE, 311)):
    p.box(u, v, 0, 18, 18, 60, sh_stone(STN, seed + 2), sh_stone(STN, seed + 3, 9, 5, -1.2), flat(STN, 4))
    p.box(u - 1, v - 1, 60, 20, 20, 3, sh_stone(STN, seed + 4, 6, 3), sh_stone(STN, seed + 5, 6, 3, -1.2), flat(STN, 5))
    for uu in range(u, u + 18, 6):
        p.box(uu, v - 1, 63, 3, 3, 5, sh_stone(STN, seed + 6, 6, 3), sh_stone(STN, seed + 7, 6, 3, -1.2), flat(STN, 5))
    hip_pyramid(p, u, v, 63, 18, 18, 26, R, seed)
    x, y = p.pt(u + 9, v + 9, 89); flag(c, int(x), int(y) - 2, 20, R)
    slit(u + 1 if u < 0 else u + 8, v, 22, 9)
    slit(u + 14 if u < 0 else u + 14, v, 40, 9)
banner(-4, 2, -8, 52, 22, RED)
banner(70, 76, -8, 52, 22, BLUE)

# ---------- 5) kapı kulesi (demir parmaklıklı kapı) ----------
GU0, GU1, GZ, GH, GV = 28, 48, 0, 46, -6
p.box(GU0, GV, GZ, GU1 - GU0, 12, GH, sh_stone(STN, 121, 9, 5, -1.3), sh_stone(STN, 122, 9, 5, -1.2), flat(STN, 4))
for uu in range(GU0, GU1, 5):
    p.box(uu, GV - 1, GH, 3, 3, 5, sh_stone(STN, 123, 6, 3), sh_stone(STN, 124, 6, 3, -1.2), flat(STN, 5))
# taş çerçeve + kemer
fr(GU0, GU1, GH - 6, GH - 5, GV, lambda u, z: STN[4] if (u % 4) else STN[1])

def gate_fn(u, z):
    cxg, rr = 38, 5.5
    in_rect = (33 <= u < 43) and z < 22
    in_arc = (u + .5 - cxg) ** 2 + (z + .5 - 22) ** 2 <= rr * rr and z >= 22
    if in_rect or in_arc:
        # parmaklık: dikey ve yatay demir çubuklar
        if u in (34, 38, 42) or (z in (6, 13, 20) and u < 43):
            return IRN[4] if u in (34, 38, 42) else IRN[3]
        if z == 0 and u in (33, 42): return IRN[5]
        return DARK
    border = (32 <= u < 44 and z < 22) or (((u + .5 - cxg) ** 2 + (z + .5 - 22) ** 2) <= (rr + 1.6) ** 2 and z >= 22)
    if border: return STN[5]
    return None
fr(31, 45, 0, 28, GV, gate_fn)
# yatay parmaklık kirişi (üst)
fr(33, 43, 21, 23, GV, lambda u, z: IRN[5] if (u % 2) else IRN[4])
# kapı kanadı (arkada, parmaklığın gerisi) - ince ahşap
# arma (kalkan)
def shield(u, z):
    if not (35 <= u < 41 and 31 <= z < 38): return None
    if z >= 36: return YEL[4]
    return RED[3] if u < 38 else BLUE[3]
fr(35, 41, 31, 38, GV, shield)
fr(35, 41, 38, 39, GV, STN[5])

# meşaleler (kapı kenarında)
torch(30, 24, GV)
torch(46, 24, GV)

# ---------- 6) son detaylar ----------
# taş zemin plakaları (kapı önü)
for uu in range(20, 56, 8):
    fr(uu, uu + 6, 0, 1, GV - 2, lambda u, z: STN[5])

# ---------- 7) gölge + meşale parıltısı + kontur ----------
layer = Cv(W_, H_)
for (x, y) in glows:
    layer.ell(x, y, 10, 10, (255, 170, 70), 60)
c.im.alpha_composite(layer.im); c.p = c.im.load()
outline(c)
shadow = Cv(W_, H_)
shadow.ell(BX + 38, BY + 6, 112, 11, (30, 40, 70), 80)
out = Cv(W_, H_)
out.im.alpha_composite(shadow.im); out.im.alpha_composite(c.im); out.p = out.im.load()
bbox = out.im.getbbox()
img = out.im.crop((bbox[0] - 2, bbox[1] - 2, bbox[2] + 2, bbox[3] + 2))
os.makedirs(OUT, exist_ok=True)
img.save(os.path.join(OUT, 'castle_v4_25d.png'))
bg = Image.new('RGBA', img.size, (94, 158, 76, 255)); bg.alpha_composite(img)
bg.resize((img.width * 3, img.height * 3), Image.NEAREST).save(os.path.join(OUT, 'castle_v4_25d_3x.png'))
print('castle size', img.size)
