#!/usr/bin/env python3
"""Mini Kingdom - bölge/slot doğrulayıcı.

Kullanım:
    python3 tools/validate_layout.py layout/kingdom_layout.json
Çıkış kodu: 0 = geçerli, 1 = hata var. Harici bağımlılık yok (sadece Python 3).
"""
import json
import sys
from itertools import combinations


def rect_cells(r):
    for yy in range(r["y"], r["y"] + r["h"]):
        for xx in range(r["x"], r["x"] + r["w"]):
            yield (xx, yy)


def rects_overlap(a, b):
    return a["x"] < b["x"] + b["w"] and b["x"] < a["x"] + a["w"] and \
           a["y"] < b["y"] + b["h"] and b["y"] < a["y"] + a["h"]


def rects_touch(a, b):
    """Kenar komşuluğu (köşe değil): aralarında en az 1 tile uzunlukta ortak kenar var."""
    x_gap = a["x"] + a["w"] == b["x"] or b["x"] + b["w"] == a["x"]
    y_gap = a["y"] + a["h"] == b["y"] or b["y"] + b["h"] == a["y"]
    y_share = a["y"] < b["y"] + b["h"] and b["y"] < a["y"] + a["h"]
    x_share = a["x"] < b["x"] + b["w"] and b["x"] < a["x"] + a["w"]
    return (x_gap and y_share) or (y_gap and x_share)


def expand(r, n):
    return {"x": r["x"] - n, "y": r["y"] - n, "w": r["w"] + 2 * n, "h": r["h"] + 2 * n}


def validate(data):
    errors, warnings, info = [], [], []
    R = data.get("rules", {})
    cols, rows = data["map"]["cols"], data["map"]["rows"]
    types = data["zone_types"]
    blds = data["buildings"]
    zones = data["zones"]
    slots = data["slots"]
    zmap = {z["id"]: z for z in zones}

    # 1) benzersiz kimlikler
    if R.get("unique_ids", True):
        ids = [z["id"] for z in zones] + [s["id"] for s in slots]
        dup = {i for i in ids if ids.count(i) > 1}
        for d in sorted(dup):
            errors.append(f"[unique_ids] Aynı kimlik birden fazla: '{d}'")

    # 2) bölge şekilleri, tip ve dikdörtgen sayısı
    for z in zones:
        if z["type"] not in types:
            errors.append(f"[zone] '{z['id']}' bilinmeyen tip '{z['type']}'")
            continue
        need = types[z["type"]].get("min_rects", 1)
        if len(z["rects"]) < need:
            errors.append(f"[zone] '{z['id']}' ({types[z['type']]['label']}) en az {need} dikdörtgen olmalı, {len(z['rects'])} var")
        for r in z["rects"]:
            if r["w"] < 1 or r["h"] < 1:
                errors.append(f"[zone] '{z['id']}' içinde boyutu sıfır/negatif dikdörtgen")
            if R.get("all_inside_map", True) and (r["x"] < 0 or r["y"] < 0 or r["x"] + r["w"] > cols or r["y"] + r["h"] > rows):
                errors.append(f"[bounds] '{z['id']}' haritanın dışına taşıyor: {r}")

    # 3) bölgeler arası çakışma ve yasak komşuluk
    if R.get("forbid_zone_overlap", True):
        for za, zb in combinations(zones, 2):
            for ra in za["rects"]:
                for rb in zb["rects"]:
                    if rects_overlap(ra, rb):
                        errors.append(f"[overlap] '{za['id']}' ile '{zb['id']}' çakışıyor: {ra} / {rb}")
                        break
    for pair in R.get("forbid_zone_touch", []):
        ta, tb = pair
        for za in (z for z in zones if z["type"] == ta):
            for zb in (z for z in zones if z["type"] == tb):
                if any(rects_touch(ra, rb) for ra in za["rects"] for rb in zb["rects"]):
                    errors.append(f"[touch] '{za['id']}' ({ta}) ile '{zb['id']}' ({tb}) birbirine değiyor; aralarında boşluk olmalı")

    # 4) slotlar: bina tanımı, boyut, bölge uyumu, harita sınırı
    cnt = {}
    for s in slots:
        b = blds.get(s["building"])
        if b is None:
            errors.append(f"[slot] '{s['id']}' bilinmeyen bina '{s['building']}'")
            continue
        cnt[s["building"]] = cnt.get(s["building"], 0) + 1
        if R.get("footprint_must_match_catalog", True) and [s["w"], s["h"]] != b["footprint"]:
            errors.append(f"[footprint] '{s['id']}' boyutu {s['w']}x{s['h']}, katalogdaki {b['footprint'][0]}x{b['footprint'][1]} olmalı")
        z = zmap.get(s["zone"])
        if z is None:
            errors.append(f"[slot] '{s['id']}' var olmayan bölgeye bağlı: '{s['zone']}'")
            continue
        if R.get("building_zone_match", True) and z["type"] not in b["allowed_zones"]:
            errors.append(f"[zone-match] '{s['id']}' ({b['label']}) '{z['type']}' bölgesine konamaz; izinli: {b['allowed_zones']}")
        if R.get("slot_inside_zone", True):
            zone_cells = {c for r in z["rects"] for c in rect_cells(r)}
            outside = [c for c in rect_cells(s) if c not in zone_cells]
            if outside:
                errors.append(f"[inside] '{s['id']}' kendi bölgesi '{z['id']}' dışında kalan {len(outside)} tile içeriyor")
        if R.get("all_inside_map", True) and (s["x"] < 0 or s["y"] < 0 or s["x"] + s["w"] > cols or s["y"] + s["h"] > rows):
            errors.append(f"[bounds] '{s['id']}' harita dışında")

    # 5) slotlar arası çakışma + minimum boşluk
    gap = R.get("min_gap_tiles", 0)
    for sa, sb in combinations(slots, 2):
        if R.get("slot_overlap_forbidden", True) and rects_overlap(sa, sb):
            errors.append(f"[overlap] '{sa['id']}' ile '{sb['id']}' üst üste")
        elif gap and rects_overlap(expand(sa, gap), sb):
            errors.append(f"[gap] '{sa['id']}' ile '{sb['id']}' arasında en az {gap} tile boşluk yok")

    # 6) bina başına üst sınır
    if R.get("max_count_enforced", True):
        for name, n in cnt.items():
            if n > blds[name]["max_count"]:
                errors.append(f"[max] {blds[name]['label']} en fazla {blds[name]['max_count']} adet, {n} tanımlı")

    # 7) tek kale
    if R.get("exactly_one_castle", True):
        n = cnt.get("castle", 0)
        if n != 1:
            errors.append(f"[castle] tam 1 kale olmalı, {n} tanımlı")

    # bilgi: bölge doluluk özeti
    for z in zones:
        n = sum(1 for s in slots if s["zone"] == z["id"])
        area = sum(r["w"] * r["h"] for r in z["rects"])
        info.append(f"{z['id']:<11} tip={z['type']:<9} rect={len(z['rects'])} alan={area:>3} tile  slot={n}")

    return errors, warnings, info


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "layout/kingdom_layout.json"
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    errors, warnings, info = validate(data)
    print(f"Doğrulama: {path}")
    for line in info:
        print("  " + line)
    for w in warnings:
        print("UYARI  " + w)
    for e in errors:
        print("HATA   " + e)
    print("SONUÇ:", "GEÇERLİ" if not errors else f"{len(errors)} HATA")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
