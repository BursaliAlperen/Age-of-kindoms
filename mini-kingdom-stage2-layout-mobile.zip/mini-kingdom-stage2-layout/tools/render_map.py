#!/usr/bin/env python3
"""Layout'u görsel haritaya çizer.

Kullanım (paket kökünden):
    python3 tools/render_map.py                       # masaüstü önizleme (etiketli, açıklamalı)
    python3 tools/render_map.py --clean               # oyun içi temiz harita (mobil arayüz için)
Çıktılar: layout/map_preview.png  |  art/map_clean.png
--clean: başlık/açıklama yok, slot etiketi yok, sadece inşa edilmiş binalar sprite olarak görünür;
boş slotlar kesikli çizgi ile gösterilir (layout/preview_state.json -> built).
"""
import json
import os
import random
import sys

from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT_B = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
CAT_COLOR = {"keep": "#d9a441", "military": "#c8442c", "civil": "#3f78c4", "resource": "#2f7a3a"}
TITLE_H, LEGEND_H = 56, 150


def hexrgb(h, a=255):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (a,)


def font(path, size):
    try:
        return ImageFont.truetype(path, size)
    except OSError:
        return ImageFont.load_default()


def label_box(d, xy, text, fnt, fg=(255, 255, 255), bg=(20, 16, 30, 215)):
    x, y = xy
    l, t, r, b = d.textbbox((x, y), text, font=fnt)
    d.rounded_rectangle((l - 5, t - 3, r + 5, b + 3), radius=4, fill=bg)
    d.text((x, y), text, font=fnt, fill=fg)


def dashed_rect(d, box, color, dash=10, width=3):
    x0, y0, x1, y1 = box
    for x in range(x0, x1, dash * 2):
        d.line((x, y0, min(x + dash, x1), y0), fill=color, width=width)
        d.line((x, y1, min(x + dash, x1), y1), fill=color, width=width)
    for y in range(y0, y1, dash * 2):
        d.line((x0, y, x0, min(y + dash, y1)), fill=color, width=width)
        d.line((x1, y, x1, min(y + dash, y1)), fill=color, width=width)


def main():
    clean = "--clean" in sys.argv
    art = os.path.join(ROOT, "art")
    data = json.load(open(os.path.join(ROOT, "layout", "kingdom_layout.json"), encoding="utf-8"))
    built = set(json.load(open(os.path.join(ROOT, "layout", "preview_state.json"), encoding="utf-8"))["built"])
    T = data["map"]["tile_px"]
    cols, rows = data["map"]["cols"], data["map"]["rows"]
    top = 0 if clean else TITLE_H
    W = cols * T
    H = rows * T + top + (0 if clean else LEGEND_H)
    img = Image.new("RGBA", (W, H), (30, 26, 40, 255))

    rnd = random.Random(7)
    grass = [Image.open(os.path.join(art, "tiles", f"grass_{i}.png")).convert("RGBA") for i in range(1, 9)]
    base = Image.new("RGBA", (W, rows * T))
    for y in range(rows):
        for x in range(cols):
            base.paste(rnd.choice(grass), (x * T, y * T))
    img.paste(base, (0, top))

    zt = data["zone_types"]
    ov = Image.new("RGBA", img.size, (0, 0, 0, 0))
    od = ImageDraw.Draw(ov)
    for z in data["zones"]:
        col = hexrgb(zt[z["type"]]["color"], 80 if clean else 90)
        for r in z["rects"]:
            x0, y0 = r["x"] * T, top + r["y"] * T
            od.rectangle((x0, y0, x0 + r["w"] * T - 1, y0 + r["h"] * T - 1), fill=col)
    img.alpha_composite(ov)
    d = ImageDraw.Draw(img)
    fb, fs, fx = font(FONT_B, 15), font(FONT, 11), font(FONT_B, 22)

    if not clean:
        for x in range(cols + 1):
            d.line((x * T, top, x * T, top + rows * T), fill=(255, 255, 255, 28))
        for y in range(rows + 1):
            d.line((0, top + y * T, cols * T, top + y * T), fill=(255, 255, 255, 28))

    for z in data["zones"]:
        color = hexrgb(zt[z["type"]]["color"])
        multi = len(z["rects"]) > 1
        for i, r in enumerate(z["rects"]):
            x0, y0 = r["x"] * T, top + r["y"] * T
            x1, y1 = x0 + r["w"] * T - 1, y0 + r["h"] * T - 1
            d.rectangle((x0, y0, x1, y1), outline=color, width=3)
            if not clean:
                name = zt[z["type"]]["label"] + (f" {chr(65 + i)}" if multi else "")
                label_box(d, (x0 + 6, y0 + 5), name, fb if not multi else fs, bg=color[:3] + (235,))

    blds = data["buildings"]
    slots = sorted(data["slots"], key=lambda s: s["y"])
    sprites = {}
    for s in slots:
        b = blds[s["building"]]
        cat = CAT_COLOR[b["category"]]
        x0, y0 = s["x"] * T, top + s["y"] * T
        fw, fh = s["w"] * T, s["h"] * T
        is_built = s["id"] in built
        if clean and not is_built:
            dashed_rect(d, (x0 + 5, y0 + 5, x0 + fw - 6, y0 + fh - 6), (255, 240, 176, 200))
            continue
        if not clean:
            d.rectangle((x0 + 1, y0 + 1, x0 + fw - 2, y0 + fh - 2), outline=hexrgb(cat), width=2)
        sp = b.get("sprite")
        if sp:
            path = os.path.join(art, "buildings", sp)
            if not os.path.exists(path):
                path = os.path.join(art, sp)
            if sp not in sprites:
                sprites[sp] = Image.open(path).convert("RGBA")
            im = sprites[sp]
            tw = fw * (1.1 if s["building"] in ("castle",) else 1.12)
            if s["building"] == "watch_post":
                tw = fw * 0.9
            k = tw / im.width
            im2 = im.resize((max(1, int(im.width * k)), max(1, int(im.height * k))), Image.LANCZOS)
            px = int(x0 + fw / 2 - im2.width / 2)
            py = int(y0 + fh - im2.height + 4)
            if 0 <= px and px + im2.width <= W and py >= 0:
                img.alpha_composite(im2, (px, py))
        else:
            tag = {"training_yard": "TALİM", "bath": "HAMAM", "temple": "KİLİSE"}.get(s["building"], "?")
            label_box(d, (x0 + fw / 2 - 26, y0 + fh / 2 - 9), tag, fs, bg=hexrgb(cat, 225))
        if not clean and s["building"] != "castle":
            label_box(d, (x0 + 3, y0 + fh - 15), s["id"], fs, bg=(20, 16, 30, 205))

    if not clean:
        d.rectangle((0, 0, W, TITLE_H - 1), fill=(24, 20, 34, 255))
        d.text((18, 14), "Mini Kingdom  -  Sabit İnşa Bölgeleri (40 x 30 tile)", font=fx, fill=(255, 226, 150))
        d.text((W - 430, 22), "Kuzey = üst   |   1 tile = 32 px", font=fs, fill=(200, 200, 210))
        ly = TITLE_H + rows * T + 10
        d.rectangle((0, ly - 8, W, H), fill=(24, 20, 34, 255))
        x = 18
        for key, z in zt.items():
            lbl = z["label"] + (" (min 2 parça)" if z.get("min_rects", 1) > 1 else "")
            d.rectangle((x, ly + 2, x + 22, ly + 16), fill=hexrgb(z["color"], 170), outline=hexrgb(z["color"]), width=2)
            d.text((x + 30, ly + 1), lbl, font=fs, fill=(235, 235, 240))
            x += 30 + d.textlength(lbl, font=fs) + 26
            if x > W - 240:
                x, ly = 18, ly + 26
        ly2 = ly + 40
        x = 18
        for cat, lbl in (("keep", "Kale"), ("military", "Askeri bina"), ("civil", "Sivil bina"), ("resource", "Kaynak binası")):
            d.rectangle((x, ly2 + 2, x + 22, ly2 + 16), outline=hexrgb(CAT_COLOR[cat]), width=3)
            d.text((x + 30, ly2 + 1), lbl, font=fs, fill=(235, 235, 240))
            x += 150
        d.text((18, ly2 + 34), f"Toplam slot: {len(data['slots'])}   |   Kurallar: python3 tools/validate_layout.py layout/kingdom_layout.json",
               font=fs, fill=(170, 170, 185))

    out = os.path.join(art, "map_clean.png") if clean else os.path.join(ROOT, "layout", "map_preview.png")
    img.convert("RGB").save(out)
    print("kaydedildi:", out, img.size)


if __name__ == "__main__":
    main()
