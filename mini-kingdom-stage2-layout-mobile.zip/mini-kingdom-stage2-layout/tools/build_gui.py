#!/usr/bin/env python3
"""Mobil (9:16) inşa arayüzü üretir: gui/build_menu.html
Kullanım (paket kökünden): python3 tools/build_gui.py
Veri (layout + preview_state) HTML'e gömülür; dosyayı tarayıcıda açmak yeterli.
Harita için önce: python3 tools/render_map.py --clean
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

TEMPLATE = r"""<!doctype html>
<html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Krallık - İnşa</title>
<style>
:root{--bg:#171424;--card:#221d33;--card2:#2c2644;--line:#3b3360;--txt:#f1ede8;--mute:#a59ec4;
--gold:#f5c451;--gold2:#c98f21;--ok:#6fd98a;--bad:#ff7a6b;--lock:#8a84a6;
--wood:#c98a4b;--food:#8fd16b;--stone:#a9b3c7;--coin:#ffd45c}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;height:100%;background:#0b0912}
body{display:grid;place-items:center;font:13px/1.3 "DejaVu Sans",system-ui,-apple-system,sans-serif;color:var(--txt);user-select:none}
#phone{position:relative;width:min(100vw,calc(100vh*9/16));height:min(100vh,calc(100vw*16/9));background:var(--bg);overflow:hidden;display:flex;flex-direction:column}
svg.i{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex:none}
/* üst çubuk: kaynaklar */
.top{display:flex;gap:5px;padding:8px 8px 4px}
.res{flex:1;display:flex;align-items:center;gap:3px;background:rgba(0,0,0,.42);border-radius:10px;padding:5px 4px;min-width:0}
.res svg{width:15px;height:15px}
.res b{font-size:11px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.r-wood{color:var(--wood)}.r-food{color:var(--food)}.r-stone{color:var(--stone)}.r-gold{color:var(--coin)}
/* bölge kısayolları */
.zones{display:flex;gap:6px;padding:4px 8px 6px;overflow-x:auto;scrollbar-width:none}
.zones::-webkit-scrollbar{display:none}
.zc{flex:none;border:1px solid var(--line);background:var(--card);color:var(--mute);border-radius:999px;padding:6px 11px;font-weight:700;font-size:12px;display:flex;align-items:center;gap:5px;cursor:pointer}
.zc i{width:8px;height:8px;border-radius:50%;display:inline-block}
.zc.on{color:#2a1d05;background:var(--gold);border-color:var(--gold)}
/* harita alanı */
#view{position:relative;flex:1;overflow:hidden;touch-action:none;background:#0d0b14}
#cam{position:absolute;left:0;top:0;width:1000px;height:750px;transition:transform .35s ease}
#cam.drag{transition:none}
#cam img{position:absolute;inset:0;width:1000px;height:750px;display:block;pointer-events:none}
.hit{position:absolute;border-radius:10px;cursor:pointer}
.mk{position:absolute;width:34px;height:34px;margin:-17px 0 0 -17px;border-radius:50%;display:flex;align-items:center;justify-content:center;
background:rgba(20,16,30,.85);border:2px solid var(--gold);color:var(--gold);box-shadow:0 2px 8px rgba(0,0,0,.5);pointer-events:none;transition:opacity .2s}
.mk svg{width:16px;height:16px;stroke-width:2.6}
.mk.lock{border-color:var(--lock);color:var(--lock)}
.mk.pulse{animation:pulse 1.1s ease-in-out infinite;background:var(--gold);color:#2a1d05}
.mk.build{border-color:#7fb8ff;color:#7fb8ff}
.dim .mk:not(.pulse){opacity:.25}
.dim .hit:not(.pulse-hit){pointer-events:none}
.plot{position:absolute;border:2px dashed rgba(255,240,176,.75);border-radius:8px;pointer-events:none;transition:opacity .2s}
.hl{position:absolute;border:3px solid var(--gold);border-radius:10px;background:rgba(245,196,81,.18);animation:pulseBox 1.1s ease-in-out infinite;pointer-events:none}
@keyframes pulse{0%,100%{box-shadow:0 0 0 0 rgba(245,196,81,.7)}70%{box-shadow:0 0 0 12px rgba(245,196,81,0)}}
@keyframes pulseBox{0%,100%{background:rgba(245,196,81,.12)}50%{background:rgba(245,196,81,.32)}}
/* inşa modu üst bandı */
#banner{position:absolute;left:8px;right:8px;top:8px;display:none;align-items:center;gap:8px;background:var(--gold);color:#2a1d05;border-radius:12px;padding:8px 8px 8px 12px;font-weight:700;box-shadow:0 4px 14px rgba(0,0,0,.4);z-index:5}
#banner.on{display:flex}
#banner span{flex:1;font-size:12.5px}
#banner button{border:0;background:rgba(0,0,0,.18);color:#2a1d05;width:30px;height:30px;border-radius:9px;cursor:pointer;display:grid;place-items:center}
/* toast */
#toast{position:absolute;left:50%;bottom:86px;transform:translate(-50%,20px);background:#fff;color:#1a1424;padding:9px 14px;border-radius:999px;font-weight:700;font-size:12px;opacity:0;transition:.25s;pointer-events:none;white-space:nowrap;z-index:9}
#toast.on{opacity:1;transform:translate(-50%,0)}
/* alt menü */
nav{display:grid;grid-template-columns:repeat(4,1fr);background:#120f1c;border-top:1px solid var(--line);padding:6px 6px calc(6px + env(safe-area-inset-bottom));z-index:4}
nav button{border:0;background:transparent;color:var(--mute);display:flex;flex-direction:column;align-items:center;gap:3px;padding:6px 0;font:600 11px inherit;cursor:pointer;border-radius:12px}
nav button svg{width:22px;height:22px}
nav button.on{color:var(--gold);background:rgba(245,196,81,.1)}
/* alttan açılan paneller */
#scrim{position:absolute;inset:0;background:rgba(0,0,0,.5);opacity:0;pointer-events:none;transition:.25s;z-index:6}
#scrim.on{opacity:1;pointer-events:auto}
.sheet{position:absolute;left:0;right:0;bottom:0;max-height:70%;background:var(--card);border-radius:18px 18px 0 0;transform:translateY(105%);transition:transform .28s cubic-bezier(.2,.8,.2,1);z-index:7;display:flex;flex-direction:column;box-shadow:0 -8px 30px rgba(0,0,0,.5)}
.sheet.on{transform:translateY(0)}
.grab{width:40px;height:4px;border-radius:4px;background:var(--line);margin:8px auto 4px}
.sh-h{display:flex;align-items:center;gap:8px;padding:4px 14px 8px}
.sh-h h3{margin:0;flex:1;font-size:15px}
.x{border:0;background:var(--card2);color:var(--txt);width:32px;height:32px;border-radius:10px;display:grid;place-items:center;cursor:pointer}
.sh-b{padding:4px 12px 16px;overflow:auto}
.seg{display:grid;grid-template-columns:repeat(4,1fr);gap:4px;background:var(--card2);border-radius:12px;padding:3px;margin-bottom:10px}
.seg button{border:0;background:transparent;color:var(--mute);padding:8px 0;border-radius:9px;font-weight:700;font-size:12px;cursor:pointer}
.seg button.on{background:var(--gold);color:#2a1d05}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.tile{position:relative;background:var(--card2);border-radius:12px;padding:6px 6px 7px;cursor:pointer;text-align:center;border:1px solid transparent}
.tile.lk{opacity:.5}
.tile:active{border-color:var(--gold)}
.ico{height:62px;display:flex;align-items:center;justify-content:center;background:#120f1c;border-radius:9px;overflow:hidden}
.ico img{max-width:100%;max-height:100%}
.ph{font-size:10px;font-weight:700;color:var(--mute);padding:4px 6px;border:1px dashed var(--line);border-radius:6px}
.tile b{display:block;font-size:11.5px;margin-top:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tile small{color:var(--mute);font-size:10.5px}
.badge{position:absolute;top:5px;right:5px;width:20px;height:20px;border-radius:50%;background:var(--bad);color:#fff;display:grid;place-items:center}
.badge svg{width:12px;height:12px;stroke-width:3}
.row{display:flex;align-items:center;gap:10px;margin-bottom:10px}
.big{width:84px;height:72px;flex:none;background:#120f1c;border-radius:12px;display:flex;align-items:center;justify-content:center;overflow:hidden}
.big img{max-width:100%;max-height:100%}
.meta{flex:1;min-width:0}
.meta b{font-size:14px;display:block}
.meta small{color:var(--mute);font-size:11.5px}
.costs{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:6px 0 12px}
.cost{background:var(--card2);border-radius:10px;padding:7px 4px;text-align:center}
.cost svg{width:16px;height:16px}
.cost b{display:block;font-size:11.5px;margin-top:2px}
.cost.no b{color:var(--bad)}
.btn{width:100%;border:0;border-radius:12px;padding:12px;font-weight:700;font-size:14px;background:var(--gold);color:#2a1d05;cursor:pointer}
.btn.sec{background:var(--card2);color:var(--txt)}
.btn:disabled{background:#3a3556;color:#7d7699;cursor:not-allowed}
.btns{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.hint{font-size:11.5px;color:var(--mute);margin:0 0 10px}
.empty{color:var(--mute);text-align:center;padding:24px 8px}
</style></head>
<body>
<div id="phone">
  <div class="top" id="top"></div>
  <div class="zones" id="zones"></div>
  <div id="view">
    <div id="cam"><img id="map" src="../art/map_clean.png" alt="Harita"></div>
    <div id="banner"><span id="bantxt"></span><button id="bcancel" aria-label="İptal"></button></div>
    <div id="toast"></div>
  </div>
  <nav id="nav"></nav>
  <div id="scrim"></div>
  <div class="sheet" id="sheet"><div class="grab"></div><div class="sh-h"><h3 id="sh-t"></h3><button class="x" id="sh-x"></button></div><div class="sh-b" id="sh-b"></div></div>
</div>
<script>
const DATA = __DATA__;
const L = DATA.layout, P = DATA.state;
const B = L.buildings, S = L.slots, Z = L.zones, ZT = L.zone_types, T = L.map.tile_px;
const K = 1000 / (L.map.cols * T);            // harita ölçeği (1000px genişlik)
const MAPW = 1000, MAPH = 750;
const CAT_NAME = {military:"Askeri", civil:"Sivil", resource:"Kaynak", keep:"Kale"};
const ZONE_CAT = {z_keep:"keep", z_military:"military", z_civil:"civil", z_mine:"resource", z_forest:"resource", z_field:"resource"};
const ZONE_SHORT = {z_keep:"Kale", z_military:"Askeri", z_civil:"Sivil", z_mine:"Maden", z_forest:"Orman", z_field:"Tarla"};
const ICON = {
  wood:'<path d="M4 7c0-2 16-2 16 0v10c0 2-16 2-16 0z"/><path d="M4 7c0 2 16 2 16 0"/><circle cx="12" cy="7" r="2"/>',
  food:'<path d="M12 21V9"/><path d="M12 9c-3 0-5-2-5-5 3 0 5 2 5 5z"/><path d="M12 13c3 0 5-2 5-5-3 0-5 2-5 5z"/><path d="M12 17c-3 0-5-2-5-5 3 0 5 2 5 5z"/>',
  stone:'<path d="M3 17l4-9 5 3 4-6 5 12z"/>',
  gold:'<circle cx="12" cy="12" r="8"/><path d="M9.5 10h4a1.5 1.5 0 010 3h-3a1.5 1.5 0 000 3h4"/>',
  lock:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  check:'<path d="M5 12l5 5 9-10"/>',
  hammer:'<path d="M14 6l4 4-8 8-4-4z"/><path d="M4 20l4-4"/><path d="M15 5l4-2 0 0"/>',
  build:'<path d="M14.7 6.3a4 4 0 00-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 005.4-5.4l-2.5 2.5-2.5-.5-.5-2.5z"/>',
  shield:'<path d="M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6z"/>',
  book:'<path d="M4 5a2 2 0 012-2h13v16H6a2 2 0 00-2 2z"/><path d="M4 19V5"/>',
  globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
  close:'<path d="M6 6l12 12M18 6L6 18"/>',
  crown:'<path d="M3 8l4 4 5-7 5 7 4-4-2 11H5z"/>',
  up:'<path d="M12 19V5M6 11l6-6 6 6"/>'
};
const svg = (n, c='') => `<svg class="i ${c}" viewBox="0 0 24 24">${ICON[n]}</svg>`;
const fmt = n => n >= 1000 ? (n/1000).toFixed(1).replace('.0','')+'K' : String(n);
const built = new Set(P.built);
const constructing = new Set();
let level = P.castle_level, zoneFocus = null, mode = null, sheetOpen = false;
const res = {...P.resources};
const count = type => S.filter(s => s.building === type && built.has(s.id)).length;
const total = type => S.filter(s => s.building === type).length;
const unlocked = type => (B[type].unlock?.castle_level || 1) <= level;
const cost = type => P.costs[type] || {wood:0,stone:0,gold:0,food:0,time:'00:30'};
const canAfford = type => { const c = cost(type); return ['wood','stone','gold','food'].every(k => (res[k]||0) >= (c[k]||0)); };
const spriteOf = type => B[type].sprite ? (B[type].sprite.startsWith('castle') ? '../art/' : '../art/buildings/') + B[type].sprite : null;
const iconEl = (type, cls='') => { const sp = spriteOf(type); return sp ? `<img src="${sp}" alt="${B[type].label}">` : `<div class="ph">${B[type].label}</div>`; };
const $ = id => document.getElementById(id);

/* üst çubuk */
function renderTop(){
  const it = (k) => `<div class="res r-${k}">${svg(k==='gold'?'gold':k)}<b>${fmt(res[k])}</b></div>`;
  $('top').innerHTML = `<div class="res" style="flex:none;color:var(--gold);padding:5px 8px">${svg('crown')}<b>Lv ${level}</b></div>` + it('wood') + it('food') + it('stone') + it('gold');
}
/* bölge kısayolları */
function renderZones(){
  $('zones').innerHTML = Z.map(z => `<button class="zc ${zoneFocus===z.id?'on':''}" data-z="${z.id}"><i style="background:${ZT[z.type].color}"></i>${ZONE_SHORT[z.id]}</button>`).join('');
  $('zones').querySelectorAll('.zc').forEach(b => b.onclick = () => focusZone(b.dataset.z));
}
/* kamera */
const cam = $('cam'), view = $('view');
let cx = 0, cy = 0;
function clampPos(x, y){
  const vw = view.clientWidth, vh = view.clientHeight;
  return [Math.min(0, Math.max(vw - MAPW, x)), Math.min(0, Math.max(vh - MAPH, y))];
}
function setCam(x, y, anim=true){
  [cx, cy] = clampPos(x, y);
  cam.style.transition = anim ? '' : 'none';
  cam.style.transform = `translate3d(${cx}px,${cy}px,0)`;
  if(!anim) requestAnimationFrame(() => cam.style.transition = '');
}
function centerTile(tx, ty, anim=true){
  const px = (tx) * T * K, py = (ty) * T * K;
  setCam(view.clientWidth/2 - px, view.clientHeight/2 - py, anim);
}
function focusZone(id){
  zoneFocus = id;
  const z = Z.find(q => q.id === id);
  const minx = Math.min(...z.rects.map(r=>r.x)), maxx = Math.max(...z.rects.map(r=>r.x+r.w));
  const miny = Math.min(...z.rects.map(r=>r.y)), maxy = Math.max(...z.rects.map(r=>r.y+r.h));
  centerTile((minx+maxx)/2, (miny+maxy)/2);
  renderZones();
}
/* sürükleme ve dokunma ayrımı */
let dn = null, moved = false;
view.addEventListener('pointerdown', e => { dn = {x:e.clientX, y:e.clientY, cx, cy}; moved = false; });
view.addEventListener('pointermove', e => {
  if(!dn) return;
  const dx = e.clientX - dn.x, dy = e.clientY - dn.y;
  if(Math.abs(dx) + Math.abs(dy) > 6){ moved = true; cam.classList.add('drag'); setCam(dn.cx + dx, dn.cy + dy, false); }
});
const endDrag = () => { dn = null; cam.classList.remove('drag'); };
view.addEventListener('pointerup', endDrag); view.addEventListener('pointercancel', endDrag);

/* harita katmanı: slotlar */
function renderMap(){
  const pick = mode ? B[mode].category : null;
  let html = '';
  // boş yer kesikli çerçeveleri (temiz harita zaten kesik çizer; yalnızca vurgu için)
  S.forEach(s => {
    const x = s.x*T*K, y = s.y*T*K, w = s.w*T*K, h = s.h*T*K;
    const b = B[s.building];
    const isBuilt = built.has(s.id) || constructing.has(s.id);
    const hl = mode && !isBuilt && s.building === mode && unlocked(mode) && count(mode) < total(mode) && (!isBuilt);
    const hit = `<div class="hit ${isBuilt?'':'nb'}" data-id="${s.id}" style="left:${x}px;top:${y}px;width:${w}px;height:${h}px"></div>`;
    html += hit;
    if(hl){
      html += `<div class="hl" style="left:${x-3}px;top:${y-3}px;width:${w+6}px;height:${h+6}px"></div>`;
    }
    if(!isBuilt){
      const lock = !unlocked(s.building);
      const cx_ = x + w/2, cy_ = y + h/2;
      const icon = lock ? svg('lock') : svg('plus');
      const cls = lock ? 'lock' : (mode && s.building===mode ? 'pulse' : '');
      html += `<div class="mk ${cls}" style="left:${cx_}px;top:${cy_}px">${icon}</div>`;
    } else if(constructing.has(s.id)){
      html += `<div class="mk build" style="left:${x+w/2}px;top:${y+h/2}px">${svg('hammer')}</div>`;
    }
  });
  // Dolu slotlar: harita görseli zaten sprite gösteriyor; sadece dokunma alanı + rozet.
  $('cam').querySelectorAll('.hit,.mk,.hl').forEach(e => e.remove());
  $('cam').insertAdjacentHTML('beforeend', html);
  $('cam').classList.toggle('dim', !!mode);
  $('cam').querySelectorAll('.hit').forEach(e => e.onclick = () => { if(moved) return; tapSlot(e.dataset.id); });
  $('cam').querySelectorAll('.hit').forEach(e => { if(mode) e.style.pointerEvents='auto'; });
}
function tapSlot(id){
  const s = S.find(q => q.id === id);
  if(mode){
    if(built.has(id) || constructing.has(id)){ openSlotInfo(s); return; }
    if(s.building === mode && unlocked(mode)) { openConfirm(s); return; }
    toast('Bu yer ' + B[mode].label + ' için uygun değil');
    return;
  }
  if(built.has(id) || constructing.has(id)) openSlotInfo(s);
  else if(!unlocked(s.building)) toast(`${B[s.building].label}: Kale Lv${B[s.building].unlock.castle_level} gerekir`);
  else openCatalog(ZONE_CAT[s.zone], s);
}

/* alt menü */
const NAV = [
  {k:'build', t:'İnşa', i:'build', on:()=>openCatalog(null)},
  {k:'army', t:'Asker', i:'shield', on:()=>toast('Asker ekranı: sonraki adım')},
  {k:'academy', t:'Akademi', i:'book', on:()=>toast('Akademi: sonraki adım')},
  {k:'world', t:'Harita', i:'globe', on:()=>{ focusZone('z_keep'); toast('Krallık merkezi'); }}
];
function renderNav(active='build'){
  $('nav').innerHTML = NAV.map(n => `<button data-k="${n.k}" class="${n.k===active?'on':''}">${svg(n.i)}${n.t}</button>`).join('');
  $('nav').querySelectorAll('button').forEach((b,i) => b.onclick = () => { renderNav(NAV[i].k); NAV[i].on(); });
}

/* panel yönetimi */
function openSheet(title, html){
  $('sh-t').textContent = title;
  $('sh-x').innerHTML = svg('close');
  $('sh-b').innerHTML = html;
  $('sheet').classList.add('on'); $('scrim').classList.add('on');
  sheetOpen = true;
}
function closeSheet(){
  $('sheet').classList.remove('on'); $('scrim').classList.remove('on'); sheetOpen = false;
}
$('sh-x').onclick = closeSheet;
$('scrim').onclick = closeSheet;

/* inşa kataloğu */
function openCatalog(cat, slot){
  cat = cat || 'military';
  const types = Object.keys(B).filter(t => B[t].category === cat && S.some(s => s.building===t));
  const seg = Object.keys(CAT_NAME).map(c => `<button data-c="${c}" class="${c===cat?'on':''}">${CAT_NAME[c]}</button>`).join('');
  const tiles = types.map(t => {
    const u = unlocked(t), full = count(t) >= total(t) || count(t) >= B[t].max_count;
    const badge = !u ? `<span class="badge" style="background:#4a4470">${svg('lock')}</span>` : '';
    return `<div class="tile ${!u?'lk':''}" data-t="${t}">${badge}<div class="ico">${iconEl(t)}</div>
      <b>${B[t].label}</b><small>${u ? count(t)+' / '+B[t].max_count : 'Lv'+B[t].unlock.castle_level}</small></div>`;
  }).join('');
  openSheet('İnşa', `<div class="seg">${seg}</div><p class="hint">Bir bina seç, sonra haritada boş yeri işaretle.</p>
    <div class="grid">${tiles || '<div class="empty">Bu kategoride bina yok</div>'}</div>`);
  $('sh-b').querySelectorAll('[data-c]').forEach(b => b.onclick = () => openCatalog(b.dataset.c));
  $('sh-b').querySelectorAll('.tile').forEach(t => t.onclick = () => {
    const type = t.dataset.t;
    if(!unlocked(type)) return toast(`${B[type].label}: Kale Lv${B[type].unlock.castle_level} gerekir`);
    if(count(type) >= B[type].max_count) return toast(B[type].label + ': limit dolu');
    startBuild(type);
  });
}
function startBuild(type){
  closeSheet(); mode = type;
  const free = S.filter(s => s.building===type && !built.has(s.id) && !constructing.has(s.id)).length;
  $('bantxt').textContent = `${B[type].label}: boş yer seç (${free})`;
  $('bcancel').innerHTML = svg('close');
  $('banner').classList.add('on');
  renderMap();
  // ilk uygun slotu ekranda göster
  const s = S.find(q => q.building===type && !built.has(q.id) && !constructing.has(q.id));
  if(s) centerTile(s.x + s.w/2, s.y + s.h/2);
}
function endBuild(){ mode = null; $('banner').classList.remove('on'); renderMap(); }
$('bcancel').onclick = endBuild;

function openConfirm(s){
  const type = s.building, c = cost(type), ok = canAfford(type);
  const costs = [['wood','wood'],['stone','stone'],['gold','gold']].map(([k]) => {
    const need = c[k]||0, have = res[k]||0;
    return need ? `<div class="cost ${have<need?'no':''}">${svg(k)}<b>${fmt(need)}</b></div>` : '';
  }).join('') + `<div class="cost">${svg('check')}<b>${c.time}</b></div>`;
  openSheet(B[type].label, `<div class="row"><div class="big">${iconEl(type)}</div>
    <div class="meta"><b>${B[type].label}</b><small>${ZT[Z.find(z=>z.id===s.zone).type].label} · ${s.w}×${s.h} alan</small>
    <br><small>Kurulunca: ${count(type)+1} / ${B[type].max_count}</small></div></div>
    <div class="costs">${costs}</div>
    <div class="btns"><button class="btn sec" id="cx">Vazgeç</button>
    <button class="btn" id="go" ${ok?'':'disabled'}>${ok?'İnşa et':'Kaynak yetersiz'}</button></div>`);
  $('cx').onclick = () => { closeSheet(); };
  $('go').onclick = () => {
    for(const k of ['wood','stone','gold']) res[k] -= (c[k]||0);
    constructing.add(s.id); closeSheet(); endBuild(); renderTop();
    toast(`${B[type].label} inşaatı başladı`);
    setTimeout(() => { constructing.delete(s.id); built.add(s.id); renderMap(); toast(`${B[type].label} tamamlandı`); }, 1800);
  };
  $('go').closest('.sh-b') && 0;
}
function openSlotInfo(s){
  const type = s.building, c = cost(type), up = (c.wood||0);
  const lvl = 1;
  openSheet(B[type].label, `<div class="row"><div class="big">${iconEl(type)}</div>
    <div class="meta"><b>${B[type].label}</b><small>Seviye ${lvl} · ${ZT[Z.find(z=>z.id===s.zone).type].label}</small></div></div>
    <div class="btns"><button class="btn sec" id="ok">Kapat</button>
    <button class="btn" id="up" ${canAfford(type)?'':'disabled'}>${svg('up')} Yükselt</button></div>`);
  $('ok').onclick = closeSheet;
  $('up').onclick = () => { toast('Yükseltme: sonraki adım'); closeSheet(); };
}
let tt = null;
function toast(msg){
  const t = $('toast'); t.textContent = msg; t.classList.add('on');
  clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 1700);
}

/* ilk çizim */
renderTop(); renderZones(); renderNav('build'); renderMap();
requestAnimationFrame(() => centerTile(21, 14, false));   // kale merkezi
window.addEventListener('resize', () => setCam(cx, cy, false));
</script></body></html>
"""


def main():
    layout = json.load(open(os.path.join(ROOT, "layout", "kingdom_layout.json"), encoding="utf-8"))
    state = json.load(open(os.path.join(ROOT, "layout", "preview_state.json"), encoding="utf-8"))
    data = json.dumps({"layout": layout, "state": state}, ensure_ascii=False)
    out = os.path.join(ROOT, "gui", "build_menu.html")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, "w", encoding="utf-8").write(TEMPLATE.replace("__DATA__", data))
    print("yazıldı:", out)


if __name__ == "__main__":
    main()
