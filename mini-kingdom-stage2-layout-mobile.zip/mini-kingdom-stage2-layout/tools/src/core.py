import math, random
from PIL import Image
def hx(s): s=s.lstrip('#'); return tuple(int(s[i:i+2],16) for i in (0,2,4))
def mix(a,b,t): return tuple(int(round(a[i]+(b[i]-a[i])*t)) for i in range(3))
DK=(28,20,58); LT=(255,240,176); OL=(16,10,32)
def mkramp(base,dk=DK,lt=LT):  # 6 tones, dark->light, hue-shifted (cool shadows, warm lights)
    return [mix(base,dk,.70),mix(base,dk,.44),mix(base,dk,.20),base,mix(base,lt,.26),mix(base,lt,.55)]
B4=[[0,8,2,10],[12,4,14,6],[3,11,1,9],[15,7,13,5]]
def q(v,x,y,d=.9):
    t=(B4[y&3][x&3]+.5)/16-.5
    return max(0,min(5,int(math.floor(v+.5+t*d))))
class Noise:
    def __init__(s,seed,n=8):
        r=random.Random(seed); s.n=n; s.g=[[r.random() for _ in range(n)] for _ in range(n)]
    def at(s,x,y,size=32):
        n=s.n; fx=x/size*n; fy=y/size*n
        x0=int(math.floor(fx)); y0=int(math.floor(fy)); tx=fx-x0; ty=fy-y0
        tx=tx*tx*(3-2*tx); ty=ty*ty*(3-2*ty); g=s.g
        a=g[y0%n][x0%n]; b=g[y0%n][(x0+1)%n]; c=g[(y0+1)%n][x0%n]; d=g[(y0+1)%n][(x0+1)%n]
        return (a*(1-tx)+b*tx)*(1-ty)+(c*(1-tx)+d*tx)*ty
class Cv:
    def __init__(s,w,h,wrap=False):
        s.w=w;s.h=h;s.wrap=wrap;s.im=Image.new('RGBA',(w,h),(0,0,0,0));s.p=s.im.load()
    def put(s,x,y,c,a=255):
        x=int(x);y=int(y)
        if s.wrap: x%=s.w;y%=s.h
        elif not(0<=x<s.w and 0<=y<s.h): return
        s.p[x,y]=(c[0],c[1],c[2],a)
    def get(s,x,y):
        x=int(x);y=int(y)
        if s.wrap: x%=s.w;y%=s.h
        elif not(0<=x<s.w and 0<=y<s.h): return (0,0,0,0)
        return s.p[x,y]
    def rect(s,x0,y0,x1,y1,c,a=255):
        for y in range(int(y0),int(y1)):
            for x in range(int(x0),int(x1)): s.put(x,y,c,a)
    def line(s,x0,y0,x1,y1,c):
        x0,y0,x1,y1=int(x0),int(y0),int(x1),int(y1)
        dx=abs(x1-x0);dy=-abs(y1-y0);sx=1 if x0<x1 else -1;sy=1 if y0<y1 else -1;e=dx+dy
        while True:
            s.put(x0,y0,c)
            if x0==x1 and y0==y1: break
            e2=2*e
            if e2>=dy: e+=dy;x0+=sx
            if e2<=dx: e+=dx;y0+=sy
    def disc(s,cx,cy,r,c):
        for y in range(int(cy-r)-1,int(cy+r)+2):
            for x in range(int(cx-r)-1,int(cx+r)+2):
                if (x+.5-cx)**2+(y+.5-cy)**2<=r*r: s.put(x,y,c)
    def ell(s,cx,cy,rx,ry,c,a=255):
        for y in range(int(cy-ry)-1,int(cy+ry)+2):
            for x in range(int(cx-rx)-1,int(cx+rx)+2):
                if ((x+.5-cx)/rx)**2+((y+.5-cy)/ry)**2<=1: s.put(x,y,c,a)
    def blit(s,o,x,y):
        s.im.alpha_composite(o.im if hasattr(o,'im') else o,(int(x),int(y))); s.p=s.im.load()
def tone_of(R,col):
    col=tuple(col[:3])
    return R.index(col) if col in R else None
def shade_px(c,x,y,R,d):
    col=c.get(x,y)
    if col[3]==0: return
    i=tone_of(R,col)
    if i is None: return
    c.put(x,y,R[max(0,min(5,i+d))])
def darken(c,x0,y0,x1,y1,amt=.35,col=DK):
    for y in range(int(y0),int(y1)):
        for x in range(int(x0),int(x1)):
            p=c.get(x,y)
            if p[3]: c.put(x,y,mix(p[:3],col,amt))
def outline(c,col=OL,amt=.74):
    src=[[c.p[x,y] for x in range(c.w)] for y in range(c.h)]
    for y in range(c.h):
        for x in range(c.w):
            if src[y][x][3]: continue
            best=None
            for dx,dy in ((0,1),(0,-1),(1,0),(-1,0)):
                xx,yy=x+dx,y+dy
                if 0<=xx<c.w and 0<=yy<c.h and src[yy][xx][3]>200:
                    p=src[yy][xx]
                    if best is None or sum(p[:3])<sum(best[:3]): best=p
            if best: c.p[x,y]=mix(best[:3],col,amt)+(255,)
def finish(c,shadow=None,ol=True):
    if ol: outline(c)
    out=Cv(c.w,c.h)
    if shadow:
        cx,cy,rx,ry=shadow
        out.ell(cx,cy,rx,ry,(30,40,70),70)
    out.im.alpha_composite(c.im); out.p=out.im.load()
    return out
