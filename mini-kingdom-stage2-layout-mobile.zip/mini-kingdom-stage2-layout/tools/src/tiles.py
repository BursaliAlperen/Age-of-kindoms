from core import *
G=mkramp(hx('5fa83f'),lt=(240,240,150)); D=mkramp(hx('8a5a34')); SD=mkramp(hx('dcc486'),dk=(120,70,80))
SN=mkramp(hx('7c8294')); F=mkramp(hx('6b4426')); Y=mkramp(hx('e0b030'),dk=(110,50,50)); W=mkramp(hx('2f7fc9'),dk=(20,20,90),lt=(200,250,255))
PB=mkramp(hx('9296aa'))
def grass(seed,flowers=0,tall=False,dark=0.0,clover=False):
    c=Cv(32,32,True);n=Noise(seed,8);n2=Noise(seed+9,16);r=random.Random(seed)
    for y in range(32):
        for x in range(32):
            v=1.9+n.at(x,y)*1.7+(n2.at(x,y)-.5)*1.0-dark
            c.put(x,y,G[q(v,x,y,.8)])
    for _ in range(26 if tall else 44):
        x=r.randrange(32);y=r.randrange(32);L=r.choice([4,5,6]) if tall else r.choice([2,2,3])
        for i in range(L):
            t=1 if i==0 else (2 if i<L-1 else 4+(i==L-1 and r.random()<.4))
            c.put(x+(1 if i>=L-1 and L>3 and r.random()<.5 else 0),y-i,G[int(t)])
        if tall: c.put(x+1,y-1,G[2]);c.put(x+1,y-2,G[3])
    if clover:
        for _ in range(7):
            x=r.randrange(32);y=r.randrange(32)
            for dx,dy in((0,0),(1,0),(0,1),(-1,0),(0,-1)): c.put(x+dx,y+dy,G[4] if (dx,dy)!=(0,0) else G[5])
            c.put(x,y+2,G[1])
    cols=[(255,255,255),(255,232,90),(255,150,190),(170,190,255)]
    for i in range(flowers):
        x=r.randrange(2,30);y=r.randrange(3,29)
        if i<2:
            for dx,dy in((1,0),(-1,0),(0,1),(0,-1)): c.put(x+dx,y+dy,(255,255,255) if i==0 else (255,170,200))
            c.put(x,y,(255,214,64)); c.put(x,y+2,G[1]);c.put(x,y+3,G[1])
        else:
            c.put(x,y,r.choice(cols)); c.put(x,y+1,G[1])
    return c.im
def dirt(seed,ruts=False):
    c=Cv(32,32,True);n=Noise(seed,8);n2=Noise(seed+5,16);r=random.Random(seed)
    for y in range(32):
        for x in range(32):
            c.put(x,y,D[q(2.0+n.at(x,y)*1.6+(n2.at(x,y)-.5)*1.1,x,y,.85)])
    for _ in range(30):
        x=r.randrange(32);y=r.randrange(32);t=r.choice([1,4]);c.put(x,y,D[t]);c.put(x+1,y,D[t+(1 if t==4 else 0)])
    if ruts:
        for y0 in (8,21):
            for x in range(32):
                dy=int(round((n.at(x,y0)-.5)*2))
                c.put(x,y0+dy,D[0]);c.put(x,y0+dy+1,D[1]);c.put(x,y0+dy+2,D[2]);c.put(x,y0+dy+3,D[4])
    for _ in range(5 if not ruts else 3):
        x=r.randrange(2,30);y=r.randrange(2,30)
        c.put(x,y+2,D[0]);c.put(x+1,y+2,D[0])
        c.put(x,y,PB[4]);c.put(x+1,y,PB[3]);c.put(x,y+1,PB[2]);c.put(x+1,y+1,PB[1])
    return c.im
def cobble_a(seed):
    c=Cv(32,32,True);r=random.Random(seed);n=Noise(seed,16)
    for ri in range(4):
        y0=ri*8;off=(ri%2)*8
        for bi in range(2):
            x0=bi*16+off;tone=r.choice([2.2,2.8,3.0,3.4])
            for ly in range(8):
                for lx in range(16):
                    x=x0+lx;y=y0+ly
                    if lx==0 or ly==7: c.put(x,y,SN[0] if ly==7 else SN[1]);continue
                    t=tone+(n.at(x,y)-.5)*1.2
                    if ly==1 or lx==1: t+=1
                    if ly==6 or lx==15: t-=1
                    if (lx in(1,2,14,15)) and (ly in (1,6)): t-=.4
                    c.put(x,y,SN[q(t,x,y,.7)])
            if r.random()<.5:
                x=x0+r.randrange(3,12);y=y0+r.randrange(2,5);c.put(x,y,SN[1]);c.put(x+1,y+1,SN[1])
    return c.im
def cobble_b(seed):
    c=Cv(32,32,True);r=random.Random(seed)
    pts=[(i*8+r.uniform(1.5,6.5),j*8+r.uniform(1.5,6.5),r.choice([2.4,2.9,3.3,3.6])) for i in range(4) for j in range(4)]
    for y in range(32):
        for x in range(32):
            ds=[]
            for (px,py,t) in pts:
                for ox in(-32,0,32):
                    for oy in(-32,0,32):
                        dx=x+.5-(px+ox);dy=y+.5-(py+oy);ds.append((dx*dx+dy*dy,dx,dy,t))
            ds.sort();d1,dx,dy,t=ds[0];d2=ds[1][0]
            e=math.sqrt(d2)-math.sqrt(d1)
            if e<1.5: c.put(x,y,SN[0] if (dx+dy)>0 else SN[1]);continue
            v=t-(dx+dy)*.22+(1 if e<2.6 and (dx+dy)<0 else 0)-(1 if e<2.6 and (dx+dy)>0 else 0)
            c.put(x,y,SN[q(v,x,y,.6)])
    return c.im
def field(kind,seed):
    c=Cv(32,32,True);n=Noise(seed,16);r=random.Random(seed)
    for y in range(32):
        for x in range(32):
            ly=y%8
            t={0:4,1:3.4,2:2.4,3:2.2,4:1.8,5:1.2,6:.6,7:.2}[ly] if kind!='wheat' else 1.6
            c.put(x,y,F[q(t+(n.at(x,y)-.5)*.9,x,y,.7)])
    if kind=='sprout':
        for row in range(4):
            for sx in range(2,32,8):
                x=sx+(row%2)*3;y=row*8+3
                c.put(x,y,G[1]);c.put(x,y-1,G[2]);c.put(x-1,y-2,G[4]);c.put(x+1,y-2,G[3]);c.put(x,y-2,G[2]);c.put(x-1,y-3,G[5]);c.put(x+2,y-3,G[4])
    if kind=='wheat':
        for row in range(4):
            yb=row*8+7
            for sx in range(0,32,2):
                x=sx+(row%2);h=8+((sx*7+row*3)%3)
                for i in range(h): c.put(x,yb-i,Y[2] if i<h-3 else Y[4])
                for i in range(3): c.put(x+1,yb-h+1+i,Y[3]);c.put(x-1,yb-h+2+i,Y[1] if i<2 else Y[2])
                c.put(x,yb-h-1,Y[5]);c.put(x,yb-h,Y[5]);c.put(x+1,yb-h+1,Y[5]);c.put(x,yb-3,G[3]);c.put(x-1,yb-4,G[2])
    return c.im
def sand(seed):
    c=Cv(32,32,True);n=Noise(seed,8);r=random.Random(seed)
    for y in range(32):
        for x in range(32):
            v=2.6+(n.at(x,y)-.5)*2.0+(0.5 if (y+int(n.at(x,y)*6))%8==0 else 0)
            c.put(x,y,SD[q(v,x,y,.8)])
    for _ in range(4):
        x=r.randrange(32);y=r.randrange(32);L=r.randrange(5,9)
        for i in range(L): c.put(x+i,y+(i%5==2 and -1 or 0),SD[4]);c.put(x+i,y+1,SD[1] if i%2==0 else SD[2])
    for _ in range(7):
        x=r.randrange(32);y=r.randrange(32);c.put(x,y,SD[0]);c.put(x+1,y,SD[1]) if r.random()<.5 else None
    return c.im
def water(f):
    c=Cv(32,32,True);n=Noise(7,8);r=random.Random(100+f);T=2*math.pi
    for y in range(32):
        for x in range(32):
            warp=.16*math.sin(T*2*x/32)+.07*math.sin(T*3*(x+y)/32)
            s=math.sin(T*(3*y/32+warp-f/3.0))
            v=2.5+s*1.15+(n.at(x,y)-.5)*.7
            if s>.94 and n.at(x*1.0,y*1.0+4)>.45: v=5
            c.put(x,y,W[q(v,x,y,.55)])
    for _ in range(5):
        x=r.randrange(32);y=r.randrange(32);c.put(x,y,(236,252,255));c.put(x+1,y,W[5])
    return c.im
def fringe(base,seed,depth,amp,mode):
    n=Noise(seed,8);r=random.Random(seed);gt=grass(seed+3,0,False,.1)
    out=base.copy();bp=base.load();op=gt.load();o=out.load()
    for x in range(32):
        d=depth+int(round((n.at(x,5.0)-.5)*2*amp))
        for y in range(d): o[x,y]=op[x,y]
        if r.random()<.45 and d>0: o[x,d-1]=G[4]+(255,)
        o[x,d]=G[1]+(255,)
        if mode=='water':
            for k,(col,p) in enumerate(((  (238,250,255),.85),((176,224,246),.6),((120,190,240),.3))):
                if r.random()<p: o[x,d+1+k]=col+(255,)
        else:
            for k,a in enumerate((.42,.2)):
                bc=bp[x,min(31,d+1+k)];o[x,d+1+k]=mix(bc[:3],DK,a)+(255,)
            if r.random()<.35: o[x,d+1]=G[2]+(255,);o[x,min(31,d+2)]=G[1]+(255,)
    return out
def edges(base,name,seed,depth,mode):
    n=fringe(base,seed,depth,2,mode)
    return {name+'_n':n,name+'_e':n.rotate(-90),name+'_s':n.rotate(180),name+'_w':n.rotate(90)}
def build_tiles():
    T={}
    for i,(fl,tl,dk,cl) in enumerate([(0,0,0,0),(0,0,.25,0),(0,0,-.15,0),(0,0,.1,0),(3,0,0,0),(4,0,.1,0),(0,1,.1,0),(0,0,0,1)]):
        T[f'grass_{i+1}']=grass(11+i*7,fl,tl,dk,cl)
    T['dirt_1']=dirt(3);T['dirt_2']=dirt(4,True)
    T['cobble_1']=cobble_a(5);T['cobble_2']=cobble_b(6)
    T['field_empty']=field('empty',1);T['field_sprout']=field('sprout',2);T['field_wheat']=field('wheat',3)
    T['sand_1']=sand(1);T['sand_2']=sand(2)
    for f in range(3): T[f'water_{f+1}']=water(f)
    T.update(edges(T['dirt_1'],'dirt_edge',21,7,'dirt'))
    T.update(edges(T['water_1'],'shore_edge',22,7,'water'))
    T.update(edges(T['sand_1'],'sand_edge',23,7,'sand'))
    return T
