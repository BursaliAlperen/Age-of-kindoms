# 2.5D oblique "bird's-eye" buildings: every face is a textured parallelogram, shaded per-face.
from core import *
from build import (RED,BLUE,THA,SLT,STN,WD,PLS,FND,GRN,YEL,FIRE,IRN,GLS,CLY,window,door,chimney,smoke,barrel,crate,sack,logs,flag,shadow_row)
KX,KY=.55,.9
class P25:
    def __init__(s,c,bx,by): s.c=c;s.bx=bx;s.by=by
    def pt(s,u,v,z): return (s.bx+u+v*KX, s.by-z-v*KY)
    def face(s,o,e1,e2,sh,tri=False):
        O=s.pt(*o);A=s.pt(o[0]+e1[0],o[1]+e1[1],o[2]+e1[2]);B=s.pt(o[0]+e2[0],o[1]+e2[1],o[2]+e2[2])
        E1=(A[0]-O[0],A[1]-O[1]);E2=(B[0]-O[0],B[1]-O[1])
        L1=math.sqrt(sum(k*k for k in e1));L2=math.sqrt(sum(k*k for k in e2))
        det=E1[0]*E2[1]-E1[1]*E2[0]
        if abs(det)<1e-6:return
        xs=[O[0],O[0]+E1[0],O[0]+E2[0],O[0]+E1[0]+E2[0]];ys=[O[1],O[1]+E1[1],O[1]+E2[1],O[1]+E1[1]+E2[1]]
        for py in range(int(min(ys))-1,int(max(ys))+2):
            for px in range(int(min(xs))-1,int(max(xs))+2):
                dx=px+.5-O[0];dy=py+.5-O[1]
                a=(dx*E2[1]-dy*E2[0])/det;b=(E1[0]*dy-E1[1]*dx)/det
                if a<-.02 or a>=1.0 or b<-.02 or b>=1.0:continue
                if tri and a+b>=1.0:continue
                col=sh(max(0,a)*L1,max(0,b)*L2,px,py)
                if col:s.c.put(px,py,col[:3],col[3] if len(col)>3 else 255)
    def box(s,u,v,z,w,d,h,shf,shs,top):
        s.face((u,v,z+h),(w,0,0),(0,d,0),top);s.face((u,v,z+h),(w,0,0),(0,0,-h),shf);s.face((u+w,v,z+h),(0,d,0),(0,0,-h),shs)
def sh_stone(R,seed,bw=9,bh=5,lt=0):
    n=Noise(seed,16)
    def f(s,t,x,y):
        row=int(t//bh);sx=s+(row%2)*(bw//2)+(row*3)%2;col=int(sx//bw);lx=sx-col*bw;ly=t-row*bh
        tone=[2.4,3.0,3.1,2.8,3.6][(col*7+row*13+seed)%5]+lt
        if lx<1:return R[1]
        if ly>=bh-1:return R[0]
        v=tone+(n.at(x,y,128)-.5)*.9
        if ly<1.5 or lx<2:v+=.9
        if ly>=bh-2.2:v-=.8
        return R[q(v,int(x),int(y),.55)]
    return f
def sh_planks(R,seed,pw=4,lt=0):
    def f(s,t,x,y):
        col=int(s//pw);lx=s-col*pw;tone=[2.5,3.0,3.3,3.6,2.8][(col*3+seed)%5]+lt
        if lx<1:return R[1]
        v=tone+(.7 if lx<2 else 0)-(.5 if lx>=pw-1 else 0)
        if int(t+col*5)%11==0 and 1<=lx<3:v-=.9
        return R[q(v,int(x),int(y),.4)]
    return f
def sh_plaster(H,posts,seed,lt=0,beam=4):
    n=Noise(seed,16)
    def f(s,t,x,y):
        for p in posts:
            if p<=s<p+3:return WD[q(3.5-(s-p)*.9+lt*.8,int(x),int(y),.3)]
        if t<beam:return WD[q(3.6-(t/beam)*.9+lt*.8-(1 if t>=beam-1 else 0),int(x),int(y),.3)]
        return PLS[q(3.2+lt+(n.at(x,y,128)-.5)*1.1,int(x),int(y),.7)]
    return f
def with_found(base,H,fh,seed,lt=0):
    fs=sh_stone(FND,seed,8,4,lt)
    return lambda s,t,x,y:fs(s,t,x,y) if t>=H-fh else base(s,t,x,y)
def with_rects(base,rects,lt=0):
    def f(s,t,x,y):
        for (s0,t0,w,h,lit) in rects:
            if s0-1<=s<s0+w+1 and t0-1<=t<t0+h+1:
                if s0<=s<s0+w and t0<=t<t0+h:
                    if lit:return YEL[q(3.6-(t-t0)/h*1.2+lt*.5,int(x),int(y),.3)]
                    return GLS[q(3.4-(t-t0)/h*1.5+lt*.5+(1 if abs((s-s0)-(t-t0))<1.2 else 0),int(x),int(y),.3)]
                return WD[1]
        return base(s,t,x,y)
    return f
def sh_roof(R,seed,Ls,Lmax,tw=8,th=5,lt=0):
    def f(s,t,x,y):
        row=int(t//th);ly=t-row*th;sx=s+(row%2)*(tw//2);col=int(sx//tw);lx=sx-col*tw
        var=[-.9,-.45,0,.45,.9,0,-.45][(col*5+row*11+seed)%7]
        v=3.7+lt-(t/Lmax)*1.3+var
        if ly>=th-1:v=.8
        elif ly>=th-2:v-=.9
        elif ly<1:v+=.7
        if lx<1:v-=.7
        if t<1.6:v=5
        elif t<3:v=max(v,4)
        if t>Lmax-1.6:return R[0]
        if t>Lmax-3.2:v-=1
        if s<1 or s>Ls-1:return R[1]
        return R[q(v,int(x),int(y),.5)]
    return f
def sh_thatch(R,seed,Ls,Lmax,lt=0):
    n=Noise(seed,16)
    def f(s,t,x,y):
        colv=(int(s)*5+int(n.at(s*3,0,128)*9))%4
        v=3.0+lt+(colv-1.5)*.45+(n.at(x,y,128)-.5)*.9-(t/Lmax)*.5
        if int(t)%6==5:v-=1.1
        if int(t)%6==0:v+=.5
        if t<1.6:v=4.8
        if t>Lmax-2:v-=1.4
        if t>Lmax-.8 or s<.8 or s>Ls-.8:return R[1]
        return R[q(v,int(x),int(y),.7)]
    return f
def flat(R,i): return lambda s,t,x,y:R[i]
def shell(W,D,wh,rh,o,f,front,side,gable,rstyle,bx,by,cw=96,ch=96,roofmaker=None):
    c=Cv(cw,ch);p=P25(c,bx,by)
    p.face((W,0,wh),(0,D,0),(0,0,-wh),side)
    if gable:p.face((W,0,wh),(0,D,0),(0,D/2,rh),gable,tri=True)
    p.face((0,0,wh),(W,0,0),(0,0,-wh),front)
    shadow_row(c,bx,bx+W,by-wh+3,5,.45)
    return c,p
def roofs(p,W,D,wh,rh,o,f,mk,**kw):
    k=rh*(1+2*f/D);hl=D/2+f;Lm=math.sqrt(hl*hl+k*k);Ls=W+2*o
    p.face((-o,D/2,wh+rh),(W+2*o,0,0),(0,hl,-k),mk(Ls,Lm,-.7,1))
    p.face((-o,D/2,wh+rh),(W+2*o,0,0),(0,-hl,-k),mk(Ls,Lm,.25,2))
def fin(c,p,W,D,sh_pad=0):
    outline(c);out=Cv(c.w,c.h);sh=Cv(c.w,c.h);q2=P25(sh,p.bx,p.by)
    q2.face((-4,-3,0),(W+12,0,0),(0,D+10,0),lambda s,t,x,y:(30,40,70,66))
    out.im.alpha_composite(sh.im);out.im.alpha_composite(c.im);out.p=out.im.load();return out
def roofmk(R,seed,tw=8,th=5):
    return lambda Ls,Lm,lt,k:sh_roof(R,seed,Ls,Lm,tw,th,lt)
def thatchmk(seed): return lambda Ls,Lm,lt,k:sh_thatch(THA,seed,Ls,Lm,lt)
def hip_pyramid(p,u,v,z,w,d,ph,R,seed):
    ap=(w/2,d/2,ph)
    for (o,e1,tag) in(((u,v+d,z),(w,0,0),'b'),((u,v,z),(0,d,0),'l'),((u+w,v,z),(0,d,0),'r'),((u,v,z),(w,0,0),'f')):
        e2=(ap[0]-(o[0]-u) if tag in('b','f') else 0,0,0)
    # front
    L=math.sqrt((d/2)**2+ph**2);Ls=w
    mk=lambda lt:sh_roof(R,seed,Ls,L,6,4,lt)
    p.face((u,v+d,z),(w,0,0),(w/2,-d/2,ph),mk(-.9),tri=True)       # back
    p.face((u,v,z),(0,d,0),(w/2,d/2,ph),sh_roof(R,seed+1,d,math.sqrt((w/2)**2+ph**2),6,4,.1),tri=True)  # left
    p.face((u+w,v,z),(0,d,0),(-w/2,d/2,ph),sh_roof(R,seed+2,d,math.sqrt((w/2)**2+ph**2),6,4,-1.0),tri=True)  # right
    p.face((u,v,z),(w,0,0),(w/2,d/2,ph),mk(.35),tri=True)         # front
def bigdoor(c,x,y,w,h):
    c.rect(x-1,y-1,x+w+1,y+h,WD[0])
    for xx in range(x,x+w):
        for yy in range(y,y+h):
            c.put(xx,yy,WD[q(3.2-(1.2 if (xx-x)%4==0 else 0)+(.7 if (xx-x)%4==1 else 0)-(1.6 if abs(xx-(x+w//2))<1 else 0),xx,yy,.35)])
    c.line(x,y,x+w//2-1,y+h-1,WD[1]);c.line(x+w-1,y,x+w//2,y+h-1,WD[1]);c.line(x,y+h-1,x+w//2-1,y,WD[1]);c.line(x+w-1,y+h-1,x+w//2,y,WD[1])
    c.rect(x,y,x+w,y+2,WD[2]);c.rect(x,y,x+w,y+1,WD[5]);c.rect(x,y+h-2,x+w,y+h,WD[1])
    for yy in(y+3,y+h-5):
        for xx in range(x,x+w):c.put(xx,yy,IRN[2])
def spear_rack(c,x,y):
    c.rect(x,y+16,x+14,y+18,WD[3]);c.rect(x,y+16,x+14,y+17,WD[5])
    for i in range(3):
        xx=x+2+i*5;c.rect(xx,y+2,xx+1,y+20,WD[3]);c.rect(xx-1,y-2,xx+2,y+3,IRN[4]);c.put(xx,y-3,IRN[5])
def dummy(c,x,y):
    c.rect(x+3,y+4,x+6,y+26,WD[3]);c.rect(x+3,y+4,x+4,y+26,WD[5]);c.rect(x-3,y+10,x+12,y+13,WD[3]);c.rect(x-3,y+10,x+12,y+11,WD[5])
    c.disc(x+4.5,y+3,3.6,THA[3]);c.disc(x+4,y+2.5,2.6,THA[5]);c.rect(x+1,y-1,x+9,y+1,WD[2]);c.rect(x,y+13,x+9,y+22,THA[2]);c.rect(x,y+13,x+9,y+14,THA[4])
def house25(kind='house'):
    W,D,wh,rh,o,f=58,28,22,13,5,3;bx,by=7,90;blue=kind=='healer'
    fr=with_rects(sh_plaster(wh,(0,20,37,55),2),[]);fr=with_found(fr,wh,5,2)
    sd=with_found(with_rects(sh_plaster(wh,(0,13,25),3,-1.3),[(9,7,9,9,not blue)],-1.3),wh,5,3,-1.3)
    gb=sh_plaster(rh+4,(0,),4,-1.2,3)
    c,p=shell(W,D,wh,rh,o,f,fr,sd,gb,None,bx,by)
    shut=BLUE if blue else RED
    window(c,bx+6,by-wh+8,11,9,shut=shut);window(c,bx+42,by-wh+8,11,9,shut=shut,lit=True)
    door(c,bx+24,by-18,12,17);c.rect(bx+22,by-1,bx+38,by+2,STN[3]);c.rect(bx+22,by-1,bx+38,by,STN[5]);c.rect(bx+22,by+1,bx+38,by+2,STN[1])
    roofs(p,W,D,wh,rh,o,f,roofmk(BLUE if blue else RED,3 if blue else 1))
    if blue:
        x,y=p.pt(W/2,D/2-9,wh+rh-5.5);c.ell(x,y,9,8,(240,244,255));c.ell(x,y,8,7,(255,255,255))
        c.rect(x-2,y-6,x+3,y+6,(214,40,48));c.rect(x-6,y-2,x+7,y+3,(214,40,48));c.rect(x-2,y-6,x+3,y-5,(255,120,120));c.rect(x-6,y-2,x+7,y-1,(255,120,120));c.rect(x-2,y+5,x+3,y+6,(140,20,50));c.rect(x-6,y+2,x+7,y+3,(140,20,50))
        for k in range(3):
            for j in range(3):c.disc(bx-4+k*4,by-1-j*3,2.2,GRN[3]);c.put(bx-5+k*4,by-2-j*3,GRN[5])
    else:
        sx=p.pt(0,0,0)
        stn=lambda s,t,x,y:STN[3]
        p.box(44,D/2-4,wh+rh-4,8,8,17,sh_stone(STN,9,5,4),sh_stone(STN,9,5,4,-1.2),lambda s,t,x,y:STN[4] if 1<=s<7 and 1<=t<7 and (s<2 or t<2) else (STN[0] if 2<=s<6 and 2<=t<6 else STN[5]))
        c.rect(bx-3,by-9,bx+3,by-2,CLY[3]);c.rect(bx-3,by-9,bx+3,by-8,CLY[5]);c.rect(bx-3,by-3,bx+3,by-2,CLY[1])
        for (x,y,col) in((bx-2,by-12,(255,90,120)),(bx,by-14,(255,230,90)),(bx+2,by-12,(255,150,190))):c.put(x,y,col);c.put(x,y+1,GRN[2])
    o2=fin(c,p,W,D)
    if not blue:
        x,y=p.pt(44+4,D/2,wh+rh-4+17);smoke(o2,x,y-1,4)
    return o2
def woodcutter25():
    W,D,wh,rh,o,f=56,26,20,11,6,3;bx,by=8,90
    fr=with_found(with_rects(sh_planks(WD,3),[(36,7,10,9,True)]),wh,4,3);sd=with_found(sh_planks(WD,5,4,-1.3),wh,4,3,-1.3);gb=sh_planks(WD,6,4,-1.2)
    c,p=shell(W,D,wh,rh,o,f,fr,sd,gb,None,bx,by)
    door(c,bx+10,by-17,13,16,WD,strap=True)
    roofs(p,W,D,wh,rh,o,f,thatchmk(5));
    logs(c,70,68,3);c.rect(2,74,12,86,WD[3]);c.ell(7,74,5,2.2,mkramp(hx('d8a868'),dk=(90,40,60))[4]);c.rect(2,74,3,86,WD[4]);c.rect(11,75,12,86,WD[1])
    c.line(7,72,13,62,WD[2]);c.line(8,72,14,62,WD[3]);c.rect(11,60,16,64,IRN[3]);c.rect(11,60,16,61,IRN[5]);c.rect(11,63,16,64,IRN[1])
    c.rect(26,86,52,88,WD[4]);c.rect(26,88,52,89,WD[1])
    for xx in(28,49):c.line(xx,88,xx-2,93,WD[2]);c.line(xx+1,88,xx+3,93,WD[2])
    return fin(c,p,W,D)
def storehouse25():
    W,D,wh,rh,o,f=62,30,24,13,5,3;bx,by=6,90
    fr=with_found(sh_planks(WD,11),wh,4,11);sd=with_found(with_rects(sh_planks(WD,12,4,-1.3),[(12,7,8,9,False)],-1.3),wh,4,11,-1.3);gb=sh_planks(WD,13,4,-1.2)
    c,p=shell(W,D,wh,rh,o,f,fr,sd,gb,None,bx,by,96,96)
    bigdoor(c,bx+18,by-21,26,20)
    roofs(p,W,D,wh,rh,o,f,roofmk(BLUE,3))
    x,y=p.pt(24,D/2-12,wh+rh-7);c.rect(x,y,x+13,y+10,(26,20,50));c.rect(x-1,y-1,x+14,y+1,WD[3]);c.rect(x-1,y-1,x+14,y,WD[5]);c.rect(x-1,y+9,x+14,y+11,WD[1]);c.rect(x-1,y,x,y+10,WD[2]);c.rect(x+13,y,x+14,y+10,WD[1])
    c.rect(x+6,y-14,x+8,y-1,WD[3]);c.rect(x+6,y-14,x+7,y-1,WD[5]);c.rect(x+3,y-17,x+20,y-14,WD[3]);c.rect(x+3,y-17,x+20,y-16,WD[5]);c.rect(x+16,y-14,x+17,y-8,(200,180,130))
    crate(c,0,76,11);crate(c,5,68,10);barrel(c,72,76);sack(c,82,80,PLS);sack(c,80,86,mkramp(hx('c8a070')))
    return fin(c,p,W,D)
def barracks25():
    W,D,wh,rh,o,f=66,30,26,13,4,3;bx,by=4,90
    st=sh_stone(STN,21);fr=with_found(st,wh,0,21);sd=with_rects(sh_stone(STN,22,9,5,-1.3),[(11,7,3,10,True),(19,7,3,10,True)],-1.3);gb=sh_stone(STN,23,9,5,-1.2)
    c,p=shell(W,D,wh,rh,o,f,fr,sd,gb,None,bx,by)
    door(c,bx+26,by-22,14,22,WD,arch=True)
    for xx in(bx+9,bx+49):
        c.rect(xx-1,by-20,xx+5,by-8,STN[0]);c.rect(xx,by-19,xx+4,by-9,(16,12,32));c.rect(xx+1,by-18,xx+3,by-10,YEL[3])
        c.rect(xx,by-8,xx+5,by+0,RED[3]);c.rect(xx,by-8,xx+5,by-7,RED[5]);c.rect(xx,by-8,xx+1,by,RED[4]);c.rect(xx+4,by-8,xx+5,by,RED[1]);c.rect(xx+1,by-5,xx+4,by-3,YEL[3])
    c.rect(bx+22,by-1,bx+44,by+2,STN[3]);c.rect(bx+22,by-1,bx+44,by,STN[5])
    roofs(p,W,D,wh,rh,o,f,roofmk(RED,21))
    x,y=p.pt(W-4,D/2,wh+rh);flag(c,x,y-22,22,RED)
    spear_rack(c,78,64);dummy(c,-6,66) if False else None
    return fin(c,p,W,D)
def smithy25():
    W,D,wh,rh,o,f=64,30,24,12,4,3;bx,by=4,90
    def front(s,t,x,y):
        base=sh_stone(STN,31) if s<38 else sh_planks(WD,31)
        return base(s,t,x,y)
    fr=with_found(front,wh,4,31)
    sd=sh_stone(SLT,32,9,5,-1.3);gb=sh_stone(SLT,33,9,5,-1.2)
    c,p=shell(W,D,wh,rh,o,f,fr,sd,gb,None,bx,by)
    x0=bx+6;y0=by-17
    c.rect(x0-1,y0-1,x0+30,by-3,STN[0]);c.rect(x0,y0,x0+29,by-3,(24,14,28))
    for y in range(y0,by-3):
        for x in range(x0,x0+29):
            dx=(x-(x0+14))/14;dy=(y-(by-3))/(by-3-y0);d=math.sqrt(dx*dx+dy*dy)
            if d<1:c.put(x,y,FIRE[q(5.3-d*4.6+((x*5+y*3)%5)*.12,x,y,.6)])
    c.rect(x0,by-6,x0+29,by-3,(30,18,30))
    for k,(xx,yy) in enumerate(((x0+4,by-9),(x0+13,by-10),(x0+20,by-8))):c.rect(xx,yy,xx+4,yy+3,(70,40,40));c.put(xx,yy,FIRE[5])
    c.rect(x0-2,y0-3,x0+31,y0-1,STN[4]);c.rect(x0-2,y0-3,x0+31,y0-2,STN[5])
    c.rect(bx+44,by-10,bx+58,by-6,IRN[3]);c.rect(bx+44,by-10,bx+58,by-9,IRN[5]);c.rect(bx+46,by-6,bx+56,by-1,IRN[2]);c.rect(bx+46,by-6,bx+47,by-1,IRN[3]);c.rect(bx+41,by-10,bx+45,by-8,IRN[4])
    roofs(p,W,D,wh,rh,o,f,roofmk(SLT,31,8,4))
    p.box(46,D/2-5,wh+rh-4,10,10,22,sh_stone(STN,9,5,4),sh_stone(STN,9,5,4,-1.2),lambda s,t,x,y:STN[5] if (s<1.5 or t<1.5 or s>8.5 or t>8.5) else STN[0])
    c.disc(76,76,7,IRN[1]);c.disc(75.5,75.5,5.5,IRN[3]);c.disc(75,75,3,IRN[4]);c.disc(76,76,1.2,WD[1]);c.rect(72,82,74,89,WD[2]);c.rect(78,82,80,89,WD[2])
    o2=fin(c,p,W,D);x,y=p.pt(46+5,D/2,wh+rh-4+22);smoke(o2,x,y-1,3);return o2
def market25():
    W,D=64,24;bx,by=10,90;c=Cv(96,96);p=P25(c,bx,by)
    for u in(2,W-5):
        p.box(u,2,0,3,3,34,sh_planks(WD,41),sh_planks(WD,42,3,-1.2),lambda s,t,x,y:WD[4])
        p.box(u,D-6,0,3,3,40,sh_planks(WD,41),sh_planks(WD,42,3,-1.2),lambda s,t,x,y:WD[4])
    p.box(6,4,0,W-12,D-12,13,sh_planks(WD,43),sh_planks(WD,44,4,-1.2),lambda s,t,x,y:WD[3] if (1<s<W-14 and 1<t<D-14) or True else WD[5])
    cols=[(230,60,60),(255,180,40),(120,200,70),(170,80,200),(255,230,90)]
    for i in range(7):
        x,y=p.pt(9+i*7.4,D/2-4,13);c.rect(x-2,y-2,x+3,y+2,WD[2]);c.rect(x-2,y-2,x+3,y-1,WD[4])
        for k in range(2):c.disc(x+k*2-.5,y-3-k%2,1.7,cols[(i+k)%5]);c.put(x+k*2-1,y-4-k%2,(255,255,255))
    pole=lambda u,v:p.box(u,v,34,3,3,6,flat(WD,3),flat(WD,1),flat(WD,5))
    def awn(s,t,x,y):
        st=int(s//8)%2;R=RED if st==0 else PLS;l=s%8
        v=3.6-(t/(D+4))*1.0+(.8 if l<1.5 else 0)-(.7 if l>=7 else 0)
        if t>D+2.5:v-=1.5
        return R[q(v,int(x),int(y),.4)]
    p.face((-4,D-3,44),(W+8,0,0),(0,-(D+2),-12),awn)
    ox,oy=map(int,p.pt(-4,-1,32))
    for i in range(0,W+8,8):
        R=RED if (i//8)%2==0 else PLS
        for k in range(8):
            h=int(max(1,4-abs(k-3.5)*.9))
            for yy in range(h):c.put(ox+i+k,oy+yy,R[q(3.0-yy*.5-1.0,ox+i+k,oy+yy,.3)])
    barrel(c,0,76);sack(c,80,82,PLS);crate(c,84,78,10)
    return fin(c,p,W,D)
def farm25():
    bx,by=24,62;W,D,wh,rh,o,f=42,24,20,10,4,3;c=Cv(96,96);p=P25(c,bx,by)
    import tiles
    wt=tiles.field('wheat',3)
    p.face((-14,-34,0),(66,0,0),(0,34,0),lambda s,t,x,y:wt.getpixel((int(s)%32,int(t)%32)))
    sh=Cv(96,96)
    p.face((W,0,wh),(0,D,0),(0,0,-wh),with_found(sh_planks(WD,51,4,-1.3),wh,3,51,-1.3))
    p.face((W,0,wh),(0,D,0),(0,D/2,rh),sh_planks(WD,52,4,-1.2),tri=True)
    p.face((0,0,wh),(W,0,0),(0,0,-wh),with_found(sh_planks(WD,53),wh,3,53))
    shadow_row(c,bx,bx+W,by-wh+3,5,.45)
    door(c,bx+16,by-15,10,14,WD)
    roofs(p,W,D,wh,rh,o,f,roofmk(RED,7,7,4))
    x,y=p.pt(14,D/2-12,wh+rh-6);c.rect(x,y,x+12,y+7,(40,20,44));c.rect(x-1,y-1,x+13,y,WD[5])
    # fence + scarecrow in field
    for u in range(-14,52,10):
        x,y=p.pt(u,-34,0);c.rect(x,y-7,x+2,y+1,WD[3]);c.rect(x,y-7,x+1,y+1,WD[5])
    x0,y0=p.pt(-14,-34,0);x1,y1=p.pt(52,-34,0);c.rect(x0,y0-5,x1+2,y0-3,WD[3]);c.rect(x0,y0-5,x1+2,y0-4,WD[5])
    for v in range(-34,0,10):
        x,y=p.pt(-14,v,0);c.rect(x,y-7,x+2,y+1,WD[3])
    x,y=p.pt(20,-16,0);c.rect(x,y-18,x+2,y-1,WD[3]);c.rect(x-6,y-14,x+9,y-12,WD[3]);c.disc(x+1,y-19,3.4,(240,200,140));c.rect(x-3,y-25,x+5,y-22,WD[2]);c.rect(x-1,y-28,x+3,y-24,WD[3]);c.rect(x-3,y-11,x+5,y-4,(190,70,60))
    c.ell(80,56,9,9,THA[3]);c.ell(79,55,8,8,THA[4]);c.ell(80,56,6,6,THA[3]);c.ell(80,56,3,3,THA[2]);c.ell(80,56,1,1,THA[1])
    return fin(c,p,W,D)
def tower25():
    W,D,H=30,28,60;bx,by=10,116;c=Cv(64,124);p=P25(c,bx,by)
    st=with_found(sh_stone(STN,61),H,0,61);ss=with_rects(sh_stone(STN,62,9,5,-1.3),[(11,18,3,9,False),(11,38,3,9,False)],-1.3)
    p.face((W,0,H),(0,D,0),(0,0,-H),ss);p.face((0,0,H),(W,0,0),(0,0,-H),st)
    p.face((0,0,H),(W,0,0),(0,D,0),lambda s,t,x,y:STN[q(2.4-t*.02,int(x),int(y),.5)] if 3<s<W-3 and 3<t<D-3 else STN[4])
    for k,(u,v) in enumerate(((0,D-7),(11,D-7),(23,D-7),(W-7,14),(W-7,0),(W-7,7) if False else (W-7,21))):
        p.box(u,v,H,7,7,6,sh_stone(STN,70+k,6,3),sh_stone(STN,71+k,6,3,-1.2),lambda s,t,x,y:STN[5])
    for u in(0,11,23):p.box(u,0,H,7,7,6,sh_stone(STN,80,6,3),sh_stone(STN,81,6,3,-1.2),lambda s,t,x,y:STN[5])
    for v in(7,14,21):pass
    c.rect(bx-2,by-H+9,bx+W+2,by-H+14,WD[3]);c.rect(bx-2,by-H+9,bx+W+2,by-H+10,WD[5]);c.rect(bx-2,by-H+13,bx+W+2,by-H+14,WD[1])
    for xx in range(bx+2,bx+W,6):c.rect(xx,by-H+11,xx+2,by-H+13,(20,14,34))
    window(c,bx+13,by-44,4,10,sill=False);door(c,bx+10,by-22,11,22,WD,arch=True)
    x,y=p.pt(3,D-3,H+6);flag(c,x,y-24,24,BLUE)
    return fin(c,p,W,D)
def castle25():
    c=Cv(168,150);bx,by=26,140;p=P25(c,bx,by);KW,KD,KH=64,34,52
    p.face((KW,0,KH),(0,KD,0),(0,0,-KH),sh_stone(STN,91,9,5,-1.3))
    p.face((0,0,KH),(KW,0,0),(0,0,-KH),sh_stone(STN,92))
    p.face((0,0,KH),(KW,0,0),(0,KD,0),lambda s,t,x,y:STN[q(2.4,int(x),int(y),.5)] if 3<s<KW-3 and 3<t<KD-3 else STN[4])
    for u in range(0,KW,12):p.box(u,0,KH,8,7,6,sh_stone(STN,93,6,3),sh_stone(STN,94,6,3,-1.2),lambda s,t,x,y:STN[5])
    for u,tw,RR,fl in((-26,26,RED,1),(KW,26,BLUE,2)):
        TH=64;TD=26
        p.face((u+tw,0,TH),(0,TD,0),(0,0,-TH),sh_stone(STN,95+fl,9,5,-1.3));p.face((u,0,TH),(tw,0,0),(0,0,-TH),sh_stone(STN,97+fl))
        hip_pyramid(p,u-3,-3,TH,tw+6,TD+6,30,RR,10*fl)
        x,y=p.pt(u+tw/2,TD/2,TH+30);flag(c,x,y-14,16,YEL)
        xx=bx+u+tw//2-1+0;c.rect(bx+u+9,by-48,bx+u+13,by-38,(16,12,32));c.rect(bx+u+10,by-47,bx+u+12,by-39,(36,30,70))
        c.rect(bx+u+9,by-30,bx+u+17,by-18,(255,150,30));c.rect(bx+u+9,by-30,bx+u+17,by-29,(255,210,110));c.rect(bx+u+9,by-19,bx+u+17,by-18,(190,70,20));c.rect(bx+u+12,by-27,bx+u+14,by-22,(255,236,150))
    for xx in(bx+10,bx+KW-14):c.rect(xx,by-40,xx+4,by-30,(16,12,32));c.rect(xx+1,by-39,xx+3,by-31,(36,30,70))
    door(c,bx+22,by-30,20,30,WD,arch=True)
    c.rect(bx+18,by-32,bx+46,by-30,STN[5]);c.rect(bx+18,by-30,bx+22,by,STN[4]);c.rect(bx+42,by-30,bx+46,by,STN[1])
    out=fin(c,p,KW+14,KD)
    return out
def build_buildings25():
    return {'house':house25('house'),'woodcutter':woodcutter25(),'storehouse':storehouse25(),'barracks':barracks25(),'smithy':smithy25(),'healer':house25('healer'),'market':market25(),'farm':farm25(),'tower_archer':tower25(),'castle':castle25()}
