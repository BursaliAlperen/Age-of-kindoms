from core import *
import tiles
RED=mkramp(hx('c8442c'),dk=(70,20,70));BLUE=mkramp(hx('3f78c4'),dk=(30,24,90));THA=mkramp(hx('d8aa3c'),dk=(100,50,50))
SLT=mkramp(hx('5f6a86'),dk=(24,20,60));STN=mkramp(hx('8a90a2'));WD=mkramp(hx('8a5a30'),dk=(50,24,50));PLS=mkramp(hx('ecdcb4'),dk=(110,70,120))
FND=mkramp(hx('6e7488'),dk=(24,20,60));GRN=mkramp(hx('4f9a3a'),lt=(235,240,140));YEL=mkramp(hx('ffd24a'),dk=(160,60,40));FIRE=mkramp(hx('ff8a1e'),dk=(120,20,40),lt=(255,250,170))
IRN=mkramp(hx('7a7e90'));GLS=mkramp(hx('6aaee0'),dk=(30,40,110),lt=(230,250,255));CLY=mkramp(hx('c8683c'),dk=(80,30,60))
def roof(c,x0,y0,x1,y1,R,seed,tw=8,th=5):
    r=random.Random(seed);rows=(y1-y0+th-1)//th
    for ri in range(rows):
        yy0=y0+ri*th;off=(ri%2)*(tw//2);x=x0-off;rb=3.7-ri/max(1,rows-1)*1.3
        while x<x1:
            tone=rb+r.choice([-.9,-.45,0,0,.45,.9])
            for yy in range(yy0,min(yy0+th,y1)):
                ly=yy-yy0
                for xx in range(max(x,x0),min(x+tw,x1)):
                    lx=xx-x;t=tone
                    if ly==th-1:t=.8
                    elif ly==th-2:t-=.9
                    elif ly==0:t+=.7
                    if lx==0:t-=.7
                    if lx==tw-1 and ly<th-2:t-=.3
                    c.put(xx,yy,R[q(t,xx,yy,.5)])
            x+=tw
    for x in range(x0,x1):c.put(x,y1-1,R[0]);c.put(x,y1-2,R[1])
    for y in range(y0,y1):c.put(x0,y,R[1]);c.put(x1-1,y,R[1])
    for x in range(x0,x1):c.put(x,y0,R[5]);c.put(x,y0+1,R[4])
def thatch(c,x0,y0,x1,y1,seed):
    n=Noise(seed,16);r=random.Random(seed)
    for y in range(y0,y1):
        for x in range(x0,x1):
            col=(x*5+int(n.at(x*3,0,128)*9))%4
            v=3.0+(col-1.5)*.45+(n.at(x,y,128)-.5)*.9-(y-y0)/(y1-y0)*.4
            if (y-y0)%6==5:v-=1.1
            if (y-y0)%6==0:v+=.5
            c.put(x,y,THA[q(v,x,y,.7)])
    for x in range(x0,x1,1):
        L=r.choice([0,1,2,2,3]);
        for k in range(L):c.put(x,y1-1-k+2,THA[1] if k else THA[0])
    for y in range(y0,y1):c.put(x0,y,THA[1]);c.put(x1-1,y,THA[1])
def stone(c,x0,y0,x1,y1,R,seed,bw=9,bh=5):
    r=random.Random(seed);n=Noise(seed,16);rows=(y1-y0+bh-1)//bh
    for ri in range(rows):
        yy0=y0+ri*bh;x=x0-((ri%2)*(bw//2)+r.randrange(0,2))
        while x<x1:
            w=bw+r.choice([-1,0,0,1]);tone=r.choice([2.2,2.9,3.0,3.1,3.7])
            for yy in range(yy0,min(yy0+bh,y1)):
                for xx in range(max(x,x0),min(x+w,x1)):
                    lx=xx-x;ly=yy-yy0
                    if lx==0 or ly==bh-1:c.put(xx,yy,R[1] if lx==0 else R[0]);continue
                    t=tone+(n.at(xx,yy,128)-.5)*1.0
                    if ly==1 or lx==1:t+=.9
                    if ly==bh-2:t-=.9
                    if lx==w-1:t-=.6
                    c.put(xx,yy,R[q(t,xx,yy,.55)])
            x+=w
def planks(c,x0,y0,x1,y1,R,seed,pw=4):
    r=random.Random(seed);n=Noise(seed,16)
    for i,xs in enumerate(range(x0,x1,pw)):
        tone=r.choice([2.4,2.9,3.2,3.5])
        for y in range(y0,y1):
            for x in range(xs,min(xs+pw,x1)):
                lx=x-xs;t=tone+(n.at(x,y,128)-.5)*.6
                if lx==0:t=.8
                elif lx==1:t+=.8
                elif lx==pw-1:t-=.5
                if (y*3+i*7)%13==0 and lx in(1,2):t-=.9
                c.put(x,y,R[q(t,x,y,.4)])
def plaster(c,x0,y0,x1,y1,seed):
    n=Noise(seed,16)
    for y in range(y0,y1):
        for x in range(x0,x1):c.put(x,y,PLS[q(3.2+(n.at(x,y,128)-.5)*1.1-(y-y0)/max(1,y1-y0)*.4,x,y,.7)])
def window(c,x,y,w,h,shut=None,lit=False,sill=True):
    if shut:
        for sx in(x-3,x+w):
            for yy in range(y,y+h):
                for xx in range(sx,sx+3):
                    c.put(xx,yy,shut[q(3.4-(xx-sx)*.5+(1 if (yy-y)%3==0 else 0)*-.9,xx,yy,.3)])
            c.put(sx+1,y+h//2,shut[0])
    c.rect(x-1,y-1,x+w+1,y+h+1,WD[0])
    for yy in range(y,y+h):
        for xx in range(x,x+w):
            if lit:t=3.8-(yy-y)/h*1.4
            else:t=3.6-(yy-y)/h*1.5+(1.2 if (xx-x)+(yy-y)==2 or (xx-x)+(yy-y)==3 and (xx-x)<w-2 else 0)
            c.put(xx,yy,(YEL if lit else GLS)[q(t,xx,yy,.4)])
    c.rect(x+w//2,y,x+w//2+1,y+h,WD[3]);c.rect(x,y+h//2,x+w,y+h//2+1,WD[3])
    if sill:c.rect(x-2,y+h+1,x+w+2,y+h+2,WD[5]);c.rect(x-2,y+h+2,x+w+2,y+h+3,WD[1])
def door(c,x,y,w,h,R=WD,arch=False,strap=True):
    c.rect(x-1,y-1,x+w+1,y+h,R[0])
    for xx in range(x,x+w):
        for yy in range(y,y+h):
            lx=xx-x
            if arch:
                rr=w/2;
                if yy<y+rr and ((xx+.5-(x+rr))/rr)**2+((yy+.5-(y+rr))/rr)**2>1.0:continue
            t=3.4-(1 if lx%4==0 else 0)*1.6+(.7 if lx%4==1 else 0)-(lx/w)*.7
            c.put(xx,yy,R[q(t,xx,yy,.35)])
    if strap:
        for sy in(y+3,y+h-6):
            for xx in range(x,x+w):c.put(xx,sy,IRN[2]);c.put(xx,sy+1,IRN[1])
            c.put(x+1,sy,IRN[5]);c.put(x+w-2,sy,IRN[5])
    c.put(x+w-3,y+h//2+1,YEL[4])
def chimney(c,x,y,h,w=8):
    stone(c,x,y,x+w,y+h,STN,9,5,4);c.rect(x-1,y,x+w+1,y+3,STN[4]);c.rect(x-1,y+3,x+w+1,y+4,STN[1])
    c.rect(x+1,y-1,x+w-1,y,STN[0])
def smoke(o,x,y,n=4):
    for i in range(n):
        r=2+i*1.1;a=int(200-i*42)
        for yy in range(int(y-i*6-r),int(y-i*6+r)+1):
            for xx in range(int(x+math.sin(i*1.3)*2.5-r),int(x+math.sin(i*1.3)*2.5+r)+1):
                if o.get(xx,yy)[3]==0 and (xx-x-math.sin(i*1.3)*2.5)**2+(yy-y+i*6)**2<=r*r:o.put(xx,yy,(236,236,246) if xx%2==yy%2 else (206,208,226),a)
def barrel(c,x,y):
    for yy in range(y,y+11):
        for xx in range(x,x+9):
            lx=xx-x;bul=1 if (yy-y) in(0,10) and lx in(0,8) else 0
            if bul:continue
            t=4.2-lx*.5+(-1.2 if (yy-y) in(2,8) else 0);c.put(xx,yy,WD[q(t,xx,yy,.3)])
    for yy in(y+2,y+8):
        for xx in range(x,x+9):c.put(xx,yy,IRN[2 if xx<x+4 else 1])
    c.rect(x+1,y,x+8,y+1,WD[5])
def crate(c,x,y,s=10):
    c.rect(x,y,x+s,y+s,WD[3]);c.rect(x,y,x+s,y+1,WD[5]);c.rect(x,y,x+1,y+s,WD[4]);c.rect(x,y+s-1,x+s,y+s,WD[1]);c.rect(x+s-1,y,x+s,y+s,WD[1])
    c.line(x+1,y+1,x+s-2,y+s-2,WD[1]);c.line(x+s-2,y+1,x+1,y+s-2,WD[2]);c.rect(x+1,y+s//2,x+s-1,y+s//2+1,WD[2]) if False else None
def sack(c,x,y,col=PLS):
    for yy in range(y,y+9):
        for xx in range(x,x+8):
            dx=(xx+.5-(x+4))/4;dy=(yy+.5-(y+5))/4.4
            if dx*dx+dy*dy<=1 and not(yy<y+3 and abs(dx)>.5):c.put(xx,yy,col[q(3.6-dx*1.0+dy*.5,xx,yy,.3)])
    c.rect(x+2,y,x+6,y+2,col[2]);c.rect(x+3,y+2,x+5,y+3,WD[2])
def logs(c,x,y,rows=3):
    rg=mkramp(hx('d8a868'),dk=(90,40,60))
    for r_ in range(rows):
        for i in range(rows-r_):
            cx=x+4+i*7+r_*3.5;cy=y+14-r_*6
            c.disc(cx,cy,3.4,WD[2]);c.disc(cx-.3,cy-.3,2.5,rg[4]);c.disc(cx,cy,1.4,rg[3]);c.put(cx-1,cy-1,rg[5]);c.disc(cx,cy,.6,WD[3])
def flag(c,x,y,h,R,right=True):
    c.rect(x,y,x+1,y+h,WD[2]);c.put(x,y-1,YEL[5])
    for i in range(9):
        for j in range(5):
            if j<5-(i//3 if i>5 else 0):c.put(x+1+i,y+1+j+(1 if i%4>1 else 0),R[q(3.6-j*.3+(i%4>1)*-.8,i,j,.3)])
def shadow_row(c,x0,x1,y,n=4,amt=.4):
    for k in range(n):darken(c,x0,y+k,x1,y+k+1,amt*(1-k/n))
def timber_house(R,seed,cross=False,flowers=False):
    c=Cv(96,96)
    stone(c,14,78,82,87,FND,seed,8,4);plaster(c,16,52,80,79,seed)
    c.rect(16,58,80,61,WD[3]);c.rect(16,58,80,59,WD[5]);c.rect(16,61,80,62,WD[1]);c.rect(16,76,80,79,WD[2])
    for px_ in(16,38,56,77):
        for yy in range(58,79):c.put(px_,yy,WD[4]);c.put(px_+1,yy,WD[3]);c.put(px_+2,yy,WD[2]) if px_ in(16,77) else None
    c.line(19,62,37,75,WD[2]);c.line(19,63,37,76,WD[1]);c.line(77,62,58,75,WD[2]);c.line(77,63,58,76,WD[1])
    window(c,24,65,10,9,shut=(RED if R is RED else BLUE));window(c,62,65,10,9,shut=(RED if R is RED else BLUE),lit=True)
    door(c,42,63,12,15);c.rect(40,78,56,81,STN[3]);c.rect(40,78,56,79,STN[5]);c.rect(40,80,56,81,STN[1])
    roof(c,9,26,87,60,R,seed,8,5);shadow_row(c,16,80,60,5)
    return c
def house():
    c=timber_house(RED,1);chimney(c,66,14,28,9)
    c.rect(11,73,18,80,CLY[3]);c.rect(11,73,18,74,CLY[5]);c.rect(11,79,18,80,CLY[1])
    for (x,y,col) in((13,70,(255,90,120)),(15,68,(255,230,90)),(17,71,(255,150,190))):c.put(x,y,col);c.put(x,y+1,GRN[2]);c.put(x,y+2,GRN[1])
    c.rect(12,72,17,73,GRN[3])
    for yy in range(62,80):
        for xx in range(78,83):
            if (xx*3+yy*5)%4: c.put(xx,yy,GRN[q(3.2+((xx+yy)%3-1)*.8,xx,yy,.5)])
    o=finish(c,(48,86,43,6));smoke(o,70,11);return o
def healer():
    c=timber_house(BLUE,2)
    c.ell(48,40,10,10,(240,244,255));c.ell(48,40,9,9,(255,255,255))
    for (x,y,w,h) in((46,33,5,15),(41,38,15,5)):c.rect(x,y,x+w,y+h,(214,40,48))
    for (x,y,w,h) in((46,33,5,1),(41,38,15,1)):c.rect(x,y,x+w,y+h,(255,110,110))
    for (x,y,w,h) in((46,47,5,1),(41,42,15,1)):c.rect(x,y,x+w,y+h,(140,20,50))
    for k in range(3):
        for j in range(3):c.disc(14+k*4,84-j*3,2.2,GRN[3]);c.put(13+k*4,83-j*3,GRN[5])
    for (x,y) in((24,76),(62,76)):c.rect(x-1,y,x+11,y+3,WD[3]);c.rect(x-1,y,x+11,y+1,WD[5]);[c.put(x+i,y-1,((255,110,150),(255,230,90),(255,255,255))[i%3]) for i in range(0,10,2)]
    return finish(c,(48,86,43,6))
def woodcutter():
    c=Cv(96,96)
    stone(c,16,78,78,86,FND,3,8,4);planks(c,18,50,76,79,WD,3,4)
    door(c,34,58,13,21,WD);window(c,54,60,10,9,shut=None,lit=True)
    thatch(c,10,20,84,56,3);shadow_row(c,18,76,56,5)
    for x in range(10,84,2):c.put(x,18+(x%5==0),THA[4]) if False else None
    # log pile
    logs(c,78,66,3)
    # chop block + axe
    c.rect(5,70,15,81,WD[3]);c.ell(10,70,5,2.2,mkramp(hx('d8a868'),dk=(90,40,60))[4]);c.rect(5,70,6,81,WD[4]);c.rect(14,71,15,81,WD[1])
    c.line(10,68,16,58,WD[2]);c.line(11,68,17,58,WD[3]);c.rect(14,57,19,61,IRN[3]);c.rect(14,57,19,58,IRN[5]);c.rect(14,60,19,61,IRN[1])
    # sawhorse
    c.rect(36,82,62,84,WD[4]);c.rect(36,84,62,85,WD[1])
    for xx in(38,59):c.line(xx,84,xx-2,90,WD[2]);c.line(xx+1,84,xx+3,90,WD[2])
    return finish(c,(46,87,44,6))
def quarry():
    c=Cv(96,96);n=Noise(5,16)
    for y in range(96):
        for x in range(96):
            d=((x+.5-48)/44)**2+((y+.5-60)/30)**2
            if d<=1:
                t=3.6-d*1.4+(n.at(x,y,128)-.5)*1.2-(1.2 if y>60 else 0)+(.6 if x<30 and y<60 else 0)
                c.put(x,y,mkramp(hx('9a6a44'),dk=(50,24,50))[q(t,x,y,.7)])
    for k,(rx,ry,cy,base) in enumerate(((36,23,62,1.0),(27,16,64,.4),(18,10,66,-.2))):
        for y in range(96):
            for x in range(96):
                d=((x+.5-48)/rx)**2+((y+.5-cy)/ry)**2
                if d<=1:
                    t=base-d*.6+(n.at(x,y,128)-.5)+(.8 if (y-cy)<-ry*.5 else 0)
                    c.put(x,y,mkramp(hx('7a4e34'),dk=(30,16,50))[q(t,x,y,.7)] if k<2 else (22,18,44))
        for x in range(48-rx,48+rx+1):
            yy=int(cy-ry*math.sqrt(max(0,1-((x+.5-48)/rx)**2)))
            c.put(x,yy,mkramp(hx('c89a68'))[5 if x<48 else 3])
    # stairs
    for i in range(5):c.rect(30+i*3,70+i*2,36+i*3,72+i*2,STN[4-i//2]) if False else None
    # crane
    c.rect(66,16,70,58,WD[3]);c.rect(66,16,67,58,WD[5]);c.rect(69,16,70,58,WD[1])
    c.line(70,58,76,64,WD[2]);c.line(66,58,60,64,WD[2])
    c.rect(34,18,72,22,WD[3]);c.rect(34,18,72,19,WD[5]);c.rect(34,21,72,22,WD[1])
    c.line(68,22,56,30,WD[2]);c.line(69,22,57,31,WD[1])
    c.rect(40,22,41,46,(230,210,150));c.rect(42,22,43,46,(120,90,70)) if False else None
    c.rect(36,46,48,54,STN[3]);c.rect(36,46,48,48,STN[5]);c.rect(36,53,48,54,STN[0]);c.rect(47,47,48,54,STN[1]);c.rect(35,44,38,46,IRN[3])
    c.rect(72,14,80,20,IRN[2]);c.rect(72,14,80,15,IRN[4])
    for (x,y,w,h) in((14,20,12,8),(22,14,12,8),(8,28,10,6),(80,38,10,8),(18,66,0,0)):
        if w:
            c.rect(x,y,x+w,y+h,STN[3]);c.rect(x,y,x+w,y+2,STN[5]);c.rect(x,y+h-2,x+w,y+h,STN[1]);c.rect(x+w-2,y,x+w,y+h,STN[1]);c.rect(x,y,x+2,y+h,STN[4])
    # cart
    c.rect(10,52,28,58,WD[3]);c.rect(10,52,28,53,WD[5]);c.rect(10,57,28,58,WD[1]);
    for xx in range(12,26,3):c.disc(xx+1,51,2.2,(30,30,44));c.put(xx,50,(90,90,110))
    c.disc(14,60,3.4,WD[0]);c.disc(24,60,3.4,WD[0]);c.disc(14,60,2,IRN[3]);c.disc(24,60,2,IRN[3]);c.put(14,60,IRN[0]);c.put(24,60,IRN[0])
    for (x,y) in((78,64),(85,52),(84,72)):
        c.disc(x,y,4,STN[2]);c.disc(x-.8,y-.8,2.6,STN[4]);c.put(x-1,y-2,STN[5])
    return finish(c,None)
def farm():
    c=Cv(96,96);t=tiles.field('wheat',3)
    for y in range(38,82):
        for x in range(10,88):c.put(x,y,t.getpixel(((x-10)%32,(y-38)%32)))
    darken(c,10,38,88,43,.35)
    for (y0,y1) in((36,38),(80,82)):
        c.rect(8,y0,90,y1,WD[3]);c.rect(8,y0,90,y0+1,WD[5]);c.rect(8,y1-1,90,y1,WD[1]) if False else None
    c.rect(8,43,10,80,WD[3]);c.rect(88,43,90,80,WD[3]) if False else None
    for x in range(8,92,12):
        c.rect(x,33,x+3,42,WD[3]);c.rect(x,33,x+1,42,WD[5]);c.rect(x+2,33,x+3,42,WD[1]);c.rect(x,32,x+3,33,WD[5])
        c.rect(x,76,x+3,85,WD[3]);c.rect(x,76,x+1,85,WD[5]);c.rect(x+2,76,x+3,85,WD[1]);c.rect(x,75,x+3,76,WD[5])
    c.rect(8,38,90,40,WD[3]);c.rect(8,38,90,39,WD[5]);c.rect(8,82,90,84,WD[3]);c.rect(8,82,90,83,WD[5]);c.rect(8,84,90,85,WD[1])
    for xx,(a,b) in((8,(36,84)),(90,(36,84))):pass
    # scarecrow
    c.rect(48,50,50,68,WD[3]);c.rect(41,55,57,57,WD[3]);c.rect(41,55,57,56,WD[5])
    c.disc(49,52,3.6,(240,200,140));c.rect(44,46,54,49,WD[2]);c.rect(46,42,52,47,WD[3]);c.rect(46,42,52,43,WD[5]);c.rect(47,52,48,53,(40,30,50)) if False else None
    c.put(48,52,(40,30,50));c.put(50,52,(40,30,50));c.rect(44,58,54,66,(190,70,60));c.rect(44,58,54,59,(230,110,90));c.rect(44,65,54,66,(120,40,60))
    # barn
    planks(c,32,16,66,36,WD,9,4);c.rect(32,34,66,37,WD[1]);door(c,44,22,10,14,WD)
    roof(c,28,4,70,20,RED,7,7,4);shadow_row(c,32,66,20,3)
    c.rect(41,9,57,16,(40,20,44));c.rect(42,10,56,11,(80,40,60)) if False else None
    c.rect(44,12,54,13,(220,190,120)) if False else None
    # hay round
    c.ell(80,12,9,9,THA[3]);c.ell(79,11,8,8,THA[4]);c.ell(80,12,6,6,THA[3]);c.ell(80,12,3,3,THA[2]);c.ell(80,12,1,1,THA[1])
    for a in range(0,360,45):
        c.line(80,12,80+int(math.cos(math.radians(a))*7),12+int(math.sin(math.radians(a))*7),THA[2])
    c.ell(80,12,1.5,1.5,THA[1])
    o=finish(c,(48,88,46,5));return o
def storehouse():
    c=Cv(96,96)
    stone(c,12,78,80,86,FND,11,8,4);planks(c,14,44,78,79,WD,11,4)
    c.rect(30,52,62,78,WD[1])
    for xx in range(31,61):
        for yy in range(53,78):c.put(xx,yy,WD[q(3.2-(1.2 if (xx-31)%4==0 else 0)+(.7 if (xx-31)%4==1 else 0)-(1.5 if xx in(45,46) else 0),xx,yy,.35)])
    c.line(31,53,45,77,WD[1]);c.line(32,53,46,77,WD[5] if False else WD[0]);c.line(60,53,46,77,WD[1]);c.line(59,53,45,77,WD[0])
    c.rect(30,52,62,54,WD[2]);c.rect(30,52,62,53,WD[5]);c.rect(30,77,62,79,WD[1]);c.rect(29,52,31,79,WD[4]);c.rect(61,52,63,79,WD[1])
    roof(c,8,14,84,50,BLUE,3,8,5);shadow_row(c,14,78,50,5)
    c.rect(34,18,44,32,(26,20,50));c.rect(34,18,44,19,WD[5]) if False else None;c.rect(33,17,45,19,WD[3]);c.rect(33,17,45,18,WD[5]);c.rect(33,32,45,33,WD[1]);c.rect(33,17,34,33,WD[2]);c.rect(44,17,45,33,WD[1])
    c.rect(40,8,43,17,WD[3]);c.rect(40,8,41,17,WD[5]);c.rect(43,8,44,17,WD[1]);c.rect(32,4,56,8,WD[3]);c.rect(32,4,56,5,WD[5]);c.rect(32,7,56,8,WD[1]) if False else None
    c.rect(50,8,51,22,(200,180,130));c.rect(48,22,54,26,WD[3]);c.rect(48,22,54,23,WD[5])
    crate(c,8,76,11);crate(c,14,68,10);barrel(c,78,72);sack(c,86,76,PLS);sack(c,82,82,mkramp(hx('c8a070')))
    return finish(c,(46,87,44,6))
def barracks():
    c=Cv(96,96)
    stone(c,8,50,86,86,STN,21,9,5);c.rect(8,82,86,86,STN[1]) if False else None
    door(c,41,58,14,24,WD,arch=True)
    for xx in(22,66):
        c.rect(xx-1,58,xx+7,72,STN[0]);c.rect(xx,59,xx+6,71,(16,12,32));c.rect(xx+2,60,xx+4,70,YEL[3]);c.rect(xx+2,60,xx+3,70,YEL[4])
        c.rect(xx-1,72,xx+7,74,STN[5]);c.rect(xx-1,73,xx+7,74,STN[1])
        for k in range(10):c.put(xx+1+ (k%2)*4,74+k//2+1,RED[3 if k%2==0 else 2]) if False else None
        c.rect(xx+1,74,xx+6,84,RED[3]);c.rect(xx+1,74,xx+6,75,RED[5]);c.rect(xx+1,74,xx+2,84,RED[4]);c.rect(xx+5,74,xx+6,84,RED[1]);c.rect(xx+2,78,xx+5,80,YEL[3])
        for k in range(3):c.put(xx+1+k*2,84,RED[1]);c.put(xx+2+k*2,85,RED[0]) if False else None
    roof(c,4,22,90,52,RED,21,8,5);shadow_row(c,8,86,52,5)
    flag(c,13,4,20,RED)
    for i in range(3):
        xx=80+i*4;c.rect(xx,56,xx+1,82,WD[3]);c.rect(xx-1,52,xx+2,57,IRN[4]);c.put(xx,51,IRN[5]);c.rect(xx,57,xx+1,58,IRN[1])
    c.rect(78,70,92,72,WD[3]);c.rect(78,70,92,71,WD[5])
    # dummy
    c.rect(5,64,8,86,WD[3]);c.rect(5,64,6,86,WD[5]);c.rect(0,68,13,71,WD[3]) if False else None
    c.rect(-1,68,14,71,WD[3]);c.rect(0,68,14,69,WD[5]);c.disc(6,61,3.4,THA[3]);c.disc(5.5,60.5,2.4,THA[5]);c.rect(2,57,10,59,WD[2])
    c.rect(2,71,10,80,THA[2]);c.rect(2,71,10,72,THA[4])
    return finish(c,(48,87,44,6))
def smithy():
    c=Cv(96,96)
    stone(c,8,54,88,86,SLT,31,9,5);planks(c,50,56,86,86,WD,31,4)
    c.rect(12,54,48,86,(0,0,0,0));stone(c,8,54,52,86,STN,32,9,5)
    # forge opening
    c.rect(13,52,45,80,STN[0]);c.rect(14,53,44,80,(24,14,28))
    for y in range(54,80):
        for x in range(14,44):
            dx=(x-29)/15;dy=(y-80)/26;d=math.sqrt(dx*dx+dy*dy)
            if d<1: c.put(x,y,FIRE[q(5.3-d*4.6+ ((x*5+y*3)%5)*.12,x,y,.6)])
    c.rect(14,74,44,80,(30,18,30));
    for x in range(14,44):c.put(x,73,(60,34,40))
    for k,(x,y) in enumerate(((20,70),(30,72),(38,70),(26,68))):c.rect(x,y,x+4,y+3,(70,40,40));c.put(x,y,FIRE[5])
    c.rect(12,50,46,53,STN[4]);c.rect(12,50,46,51,STN[5]);c.rect(12,53,46,54,STN[1])
    c.rect(55,70,69,74,IRN[3]);c.rect(55,70,69,71,IRN[5]);c.rect(52,73,60,75,IRN[2]);c.rect(57,74,67,84,IRN[1]) if False else None;c.rect(58,74,66,82,IRN[2]);c.rect(58,74,59,82,IRN[3]);c.rect(65,74,66,82,IRN[1]);c.rect(52,70,56,72,IRN[4])
    # grindstone
    c.disc(78,76,7,IRN[1]);c.disc(77.5,75.5,5.5,IRN[3]);c.disc(77,75,3,IRN[4]);c.disc(78,76,1.2,WD[1]);c.line(72,69,84,83,IRN[1]) if False else None
    c.rect(74,82,76,88,WD[2]);c.rect(80,82,82,88,WD[2])
    # tools rack
    c.rect(72,58,86,59,WD[3]);
    for xx in(74,78,82):c.rect(xx,59,xx+1,66,IRN[3])
    roof(c,4,22,92,56,SLT,31,8,4);shadow_row(c,8,88,56,5)
    chimney(c,62,12,32,10)
    o=finish(c,(48,87,44,6));smoke(o,67,10,3);return o
def market():
    c=Cv(96,96)
    for xx in(10,82):c.rect(xx,36,xx+4,84,WD[3]);c.rect(xx,36,xx+1,84,WD[5]);c.rect(xx+3,36,xx+4,84,WD[1])
    planks(c,14,54,82,84,WD,41,4)
    c.rect(10,48,86,52,WD[3]);c.rect(10,48,86,49,WD[5]);c.rect(10,51,86,52,WD[1])
    # goods
    cols=[(230,60,60),(255,180,40),(120,200,70),(170,80,200),(255,230,90),(230,60,60),(120,200,70),(255,180,40)]
    for i,xx in enumerate(range(16,80,8)):
        c.rect(xx,44,xx+7,49,WD[2]);c.rect(xx,44,xx+7,45,WD[4])
        for k in range(3):
            c.disc(xx+1.5+k*2,43-(k%2),1.8,cols[(i+k)%len(cols)]);c.put(xx+1+k*2,42-(k%2),(255,255,255))
    # awning
    for y in range(8,34):
        for x in range(6,90):
            st=((x-6)//8)%2
            tone=(RED if st==0 else PLS)
            t=3.5-(y-8)/26*1.2+(.8 if (x-6)%8==1 else 0)-(.7 if (x-6)%8==7 else 0)
            c.put(x,y,tone[q(t,x,y,.4)])
    for i,x0 in enumerate(range(6,90,8)):
        tone=RED if i%2==0 else PLS
        for k in range(8):
            h=4-abs(k-3.5)*.9
            for yy in range(34,34+int(max(1,h))):c.put(x0+k,yy,tone[q(3.0-(yy-34)*.5,x0+k,yy,.3)])
    c.rect(6,6,90,9,WD[3]);c.rect(6,6,90,7,WD[5]);c.rect(6,8,90,9,WD[1])
    c.rect(44,50,52,54,(255,214,64)) if False else None
    c.rect(44,40,52,48,(250,220,130));c.rect(44,40,52,41,(255,250,190));c.ell(48,44,2.5,2,(230,170,40));c.put(47,43,(255,255,230))
    # side props
    barrel(c,5,74);sack(c,84,76,PLS);crate(c,76,78,10)
    return finish(c,(48,87,44,6))
def scaffold():
    c=Cv(96,96);n=Noise(7,16)
    for y in range(40,88):
        for x in range(10,86):
            if ((x-48)/38)**2+((y-62)/24)**2<=1:c.put(x,y,mkramp(hx('8a5a34'))[q(2.7+(n.at(x,y,128)-.5)*1.4-(y-62)*.02,x,y,.8)])
    for xx in(14,40,66):
        c.rect(xx,8,xx+4,70,WD[3]);c.rect(xx,8,xx+1,70,WD[5]);c.rect(xx+3,8,xx+4,70,WD[1])
    for yy in(20,44,64):
        c.rect(10,yy,74,yy+4,WD[3]);c.rect(10,yy,74,yy+1,WD[5]);c.rect(10,yy+3,74,yy+4,WD[1])
    c.line(18,64,44,44,WD[2]);c.line(19,64,45,44,WD[1]);c.line(44,44,70,20,WD[2]);c.line(45,44,71,20,WD[1])
    for i in range(5):c.rect(66,70+i*3,86,73+i*3,WD[2 if i%2 else 3]);c.rect(66,70+i*3,86,71+i*3,WD[5 if i%2==0 else 4])
    for i in range(0,10):c.rect(6,8+i*6,10,12+i*6,WD[2 if i%2 else 3]) if False else None
    c.rect(4,18,8,76,WD[3]);c.rect(4,18,5,76,WD[5])
    for (x,y) in((20,74),(30,78)):c.disc(x,y,3,STN[2]);c.disc(x-.7,y-.7,1.8,STN[4])
    return finish(c,None)
def _pillar(c,x0,y0,x1,y1,seed):
    stone(c,x0,y0,x1,y1,STN,seed,7,5);c.rect(x0-1,y0,x1+1,y0+3,STN[5]);c.rect(x0-1,y0+2,x1+1,y0+3,STN[2]);c.rect(x0-1,y0+3,x1+1,y0+4,STN[1])
def _face(c,x0,y0,x1,y1,seed):
    stone(c,x0,y0,x1,y1,STN,seed,8,5)
    for xx in range(x0,x1,11):
        c.rect(xx,y0-5,min(x1,xx+7),y0,STN[3]);c.rect(xx,y0-5,min(x1,xx+7),y0-3,STN[5]);c.rect(xx,y0-4,xx+1,y0,STN[4]);c.rect(min(x1,xx+7)-1,y0-5,min(x1,xx+7),y0,STN[1])
        c.rect(xx,y0-1,min(x1,xx+7),y0,STN[1])
    c.rect(x0,y0,x1,y0+2,STN[5]);c.rect(x0,y0+2,x1,y0+3,STN[1])
def wall_h():
    c=Cv(48,44);_face(c,0,12,48,36,3);return finish(c,(24,38,22,3))
def wall_v():
    c=Cv(20,44);_pillar(c,3,6,17,38,4);c.rect(2,38,18,40,STN[1]);return finish(c,(10,40,9,2))
def wall_corner():
    c=Cv(52,44);_face(c,14,12,52,36,5);_pillar(c,0,4,16,38,6);c.rect(0,38,17,40,STN[1]);return finish(c,(26,38,24,3))
def wall_end():
    c=Cv(52,44);_face(c,0,12,38,36,7);_pillar(c,36,4,52,38,8);return finish(c,(26,38,24,3))
def wall_t():
    c=Cv(72,44);_face(c,0,12,72,36,9);_pillar(c,28,2,44,40,10);c.rect(27,40,45,42,STN[1]);return finish(c,(36,40,34,3))
def gate():
    c=Cv(64,52);stone(c,0,14,64,48,STN,12,8,5)
    for xx in range(0,64,11):
        c.rect(xx,9,min(64,xx+7),14,STN[3]);c.rect(xx,9,min(64,xx+7),11,STN[5]);c.rect(xx,10,xx+1,14,STN[4]);c.rect(min(64,xx+7)-1,9,min(64,xx+7),14,STN[1])
    c.rect(0,14,64,16,STN[5]);c.rect(0,16,64,17,STN[1])
    door(c,18,22,28,26,WD,arch=True);c.rect(14,20,18,48,STN[4]);c.rect(46,20,50,48,STN[1]);c.rect(14,20,50,22,STN[5]) if False else None
    c.rect(30,22,34,48,WD[0]) if False else None
    c.rect(4,22,10,30,(16,12,32));c.rect(5,23,9,29,YEL[2]) if False else None
    return finish(c,(32,48,30,3))
def castle():
    c=Cv(168,160);W=168
    stone(c,46,60,122,148,STN,51,10,5)
    for xx in range(46,122,13):
        c.rect(xx,50,min(122,xx+9),60,STN[3]);c.rect(xx,50,min(122,xx+9),53,STN[5]);c.rect(xx,51,xx+1,60,STN[4]);c.rect(min(122,xx+9)-1,50,min(122,xx+9),60,STN[1])
    c.rect(46,60,122,63,STN[5]);c.rect(46,63,122,64,STN[1])
    for (x,y) in((60,72),(60,100),(100,72),(100,100)):c.rect(x,y,x+4,y+10,(16,12,32));c.rect(x+1,y+1,x+3,y+9,(36,30,70))
    stone(c,36,92,52,148,STN,52,9,5);stone(c,116,92,132,148,STN,53,9,5)
    for (x0,cx,R,seed) in((8,31,RED,54),(110,137,BLUE,55)):
        pass
    for (x0,x1,cone,seed,fl) in((6,60,RED,54,(0,0)),(108,162,BLUE,55,(0,0))):
        stone(c,x0+4,70,x1-4,148,STN,seed,9,5);c.rect(x0+2,64,x1-2,72,STN[3]);c.rect(x0+2,64,x1-2,66,STN[5]);c.rect(x0+2,71,x1-2,72,STN[1])
        cx=(x0+x1)//2;hw=(x1-x0)//2+4;ytop=14;ybot=66
        for y in range(ytop,ybot):
            half=hw*(y-ytop)/(ybot-ytop)
            for x in range(int(cx-half),int(cx+half)+1):
                u=(x-cx)/hw;ry=y-ytop;t=4.2-(u+1)*1.45+(.5 if ry<10 else 0)
                if ry%5==4:t-=1.4
                if (x+(ry//5)%2*4)%8==0:t-=.9
                c.put(x,y,cone[q(t,x,y,.5)])
        c.rect(x0-2,ybot-1,x1+2,ybot+2,cone[0]);c.rect(x0-2,ybot-1,x1+2,ybot,cone[2])
        flag(c,cx,2,14,(YEL if cone is RED else (YEL)))
        for k,xx in enumerate((cx-5,cx+3)):c.rect(xx,86,xx+3,98,(16,12,32));c.rect(xx+1,87,xx+2,97,(36,30,70))
        bx=cx-5;c.rect(bx,110,bx+11,126,(255,150,30) if True else None);c.rect(bx,110,bx+11,111,(255,210,110));c.rect(bx,125,bx+11,126,(190,70,20));c.rect(bx+4,113,bx+7,120,(255,236,150))
        for k in range(4):c.put(bx+k*3,126,(255,150,30));c.put(bx+1+k*3,127,(190,70,20)) if False else None
    door(c,70,100,28,48,WD,arch=True);c.rect(64,96,104,100,STN[4]) if False else None
    c.rect(66,98,70,148,STN[4]);c.rect(98,98,102,148,STN[1]);c.rect(66,94,102,98,STN[5]);c.rect(66,97,102,98,STN[1])
    c.rect(66,148,102,152,STN[2]);c.rect(66,148,102,149,STN[4])
    return finish(c,(84,150,78,6))
def tower():
    c=Cv(64,104)
    stone(c,10,40,54,98,STN,61,9,5)
    c.rect(8,34,56,44,WD[3]);c.rect(8,34,56,36,WD[5]);c.rect(8,43,56,44,WD[1]);planks(c,10,36,54,43,WD,62,4)
    for xx in range(14,52,10):c.rect(xx,38,xx+2,42,(20,14,34))
    for xx in range(8,56,12):
        c.rect(xx,24,min(56,xx+8),34,STN[3]);c.rect(xx,24,min(56,xx+8),27,STN[5]);c.rect(xx,25,xx+1,34,STN[4]);c.rect(min(56,xx+8)-1,24,min(56,xx+8),34,STN[1])
    c.rect(8,33,56,34,STN[1])
    for (x,y) in((26,52),(26,70)):c.rect(x,y,x+4,y+9,(16,12,32));c.rect(x+1,y+1,x+3,y+8,(36,30,70))
    door(c,23,78,18,20,WD,arch=True);c.rect(18,94,46,98,STN[2]);c.rect(18,94,46,95,STN[4])
    flag(c,20,2,24,BLUE)
    return finish(c,(32,100,26,3))
def build_buildings():
    B={}
    for k,f in(('house',house),('woodcutter',woodcutter),('quarry',quarry),('farm',farm),('storehouse',storehouse),('barracks',barracks),('smithy',smithy),('market',market),('healer',healer),('castle',castle),('tower_archer',tower),('scaffold',scaffold),('gate',gate),('wall_h',wall_h),('wall_v',wall_v),('wall_corner',wall_corner),('wall_end',wall_end),('wall_t',wall_t)):
        r=f();B[k]=r.im if isinstance(r,Cv) else r
    return B
